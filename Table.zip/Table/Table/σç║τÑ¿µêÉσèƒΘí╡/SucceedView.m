//
//  SucceedView.m
//  hipiaonew
//
//  Created by OceanSea on 16/4/15.
//  Copyright © 2016年 dadi. All rights reserved.
//

#import "SucceedView.h"
#import "TicketsCodeModel.h"
@interface SucceedView ()





@property (nonatomic, strong) UIImageView   * imgInfotitle;
@property (nonatomic, strong) UIImageView   * imgInfocenter;


@property (nonatomic, strong) UIImageView   * imgInfoTime;
@property (nonatomic, strong) UIImageView   * imgInfoAddress;
@property (nonatomic, strong) UIImageView   * imgInfoPhone;

@property (nonatomic, strong) UILabel * filmName;
@property (nonatomic, strong) UILabel * filmType;
@property (nonatomic, strong) UILabel * filmSeaton;
@property (nonatomic, strong) UILabel * filmSeattw;
@property (nonatomic, strong) UILabel * filmSeatth;
@property (nonatomic, strong) UILabel * filmSeatfo;
@property (nonatomic, strong) UILabel * filmTime;
@property (nonatomic, strong) UILabel * filmAddress;
@property (nonatomic, strong) UILabel * filmPhone;

@property (nonatomic, strong) UILabel * ticketCode;
@property (nonatomic, strong) UILabel * ticketNumb;

@property (nonatomic, strong) UILabel * lightLinelb;

@property (nonatomic, strong) UILabel * payDetail;
@property (nonatomic, strong) UILabel * cardCount;
@property (nonatomic, strong) UILabel * balanceCount;

@property (nonatomic, strong) UIButton * btnKeep;
@property (nonatomic, strong) UIButton * btnShare;

@property (nonatomic, strong) UIImageView * imgInfofooter;
@property (nonatomic, strong) UILabel * lbNotice;
@property (nonatomic, strong) UILabel * lbNoticeDetail;



@property (nonatomic, strong) UIImageView * imgLogophone;
@property (nonatomic, strong) UILabel * lbPhoneNum;
@property (nonatomic, strong) UILabel * lbNotices;
@property (nonatomic, strong) UIImageView * imgLogo;
@property (nonatomic, strong) UILabel * lbNoticeSpt;

@property (nonatomic, strong) UIView   * viewButton;
@property (nonatomic, strong) UIButton * btnBackFirst;



@property (nonatomic, strong) UIImageView * imgCodeQR;
@property (nonatomic, strong) UIImageView * imgCodeBar;



@property (nonatomic, strong) UIView  * headBackView;
@property (nonatomic, strong) UILabel * statusLabel;
@property (nonatomic, strong) UIImageView * infoBackView;
@property (nonatomic, strong) UIView  * infoView;

@property (nonatomic, strong) UILabel * codeNote;
@property (nonatomic, strong) UILabel * codeDetail;

@property (nonatomic, strong) UIView  * serialBack;
@property (nonatomic, strong) UILabel * serialNote;
@property (nonatomic, strong) UILabel * serialNum;

@property (nonatomic, strong) UILabel * mobileNote;
@property (nonatomic, strong) UILabel * mobileDetail;

@property (nonatomic, strong) UILabel * kindNote;
@property (nonatomic, strong) UILabel * noteDetail;

@property (nonatomic, strong) UILabel * prizeLabel;

@property (nonatomic, strong) UIButton * backButton;
//@property (nonatomic, strong) UIButton * checkButton;

@property (nonatomic, strong) UIView  * teleBackView;
@property (nonatomic, strong) UIImageView * teleView;
@property (nonatomic, strong) UILabel * teleLabel;

@property (nonatomic, strong) MASConstraint * prizesCon;
@property (nonatomic, strong) MASConstraint * serialCon;

@end

@implementation SucceedView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {

        self.backgroundColor = [[UIColor lightGrayColor]colorWithAlphaComponent:0.2];
        [self setup];
        [self refreshState];
    }
    return self;
}
- (void)refreshState{

    CIFilter *filter = [CIFilter filterWithName:@"CIQRCodeGenerator"];
    // 2.恢复默认
    [filter setDefaults];
    // 3.给过滤器添加数据
    NSString * dataString = @"hahahahhahahahahahahahahahahahhahahahahahaahha";
    NSData   * data = [dataString dataUsingEncoding:NSUTF8StringEncoding];
    // 4.通过KVO设置滤镜inputMessage数据
    [filter setValue:data forKeyPath:@"inputMessage"];
    // 4.获取输出的二维码
    CIImage *outputImage = [filter outputImage];
    
    
    //生成二维码
    self.imgCodeQR.image = [TicketsCodeModel createNonInterpolatedUIImageFormCIImage:outputImage withSize:200];
    
    //生成条形码
    self.imgCodeBar.image = [TicketsCodeModel generateBarCode:@"1234948958096" width:200 height:100];


}
- (void)setup
{
    [self addSubview:self.bgScrollView];
    
    [self.bgScrollView addSubview:self.imgInfotitle];
    
    [self.bgScrollView addSubview:self.imgInfocenter];
    [self.bgScrollView addSubview:self.imgInfofooter];
    [self.bgScrollView addSubview:self.viewButton];
    
    [self.imgInfotitle addSubview:self.filmName];
    [self.imgInfotitle addSubview:self.filmType];
    [self.imgInfotitle addSubview:self.filmSeaton];
    [self.imgInfotitle addSubview:self.filmSeattw];
    [self.imgInfotitle addSubview:self.filmSeatth];
    [self.imgInfotitle addSubview:self.filmSeatfo];
    
    [self.imgInfotitle addSubview:self.imgInfoTime];
    [self.imgInfotitle addSubview:self.imgInfoAddress];
    [self.imgInfotitle addSubview:self.imgInfoPhone];
    [self.imgInfotitle addSubview:self.filmTime];
    [self.imgInfotitle addSubview:self.filmAddress];
    [self.imgInfotitle addSubview:self.filmPhone];
    
    [self.imgInfocenter addSubview:self.ticketCode];
    [self.imgInfocenter addSubview:self.ticketNumb];
    [self.imgInfocenter addSubview:self.imgCodeQR];
    [self.imgInfocenter addSubview:self.imgCodeBar];
    
    [self.imgInfocenter addSubview:self.lightLinelb];
    
    [self.imgInfocenter addSubview:self.payDetail];
    [self.imgInfocenter addSubview:self.cardCount];
    [self.imgInfocenter addSubview:self.balanceCount];
    
    
    [self.imgInfocenter addSubview:self.btnKeep];
    [self.imgInfocenter addSubview:self.btnShare];
  
    
    
    
    [self.imgInfofooter addSubview:self.lbNotice];
    [self.imgInfofooter addSubview:self.lbNoticeDetail];
    
    
    [self.bgScrollView addSubview:self.imgLogophone];
    [self.bgScrollView addSubview:self.lbPhoneNum];
    [self.bgScrollView addSubview:self.lbNotices];
    [self.bgScrollView addSubview:self.imgLogo];
    [self.bgScrollView addSubview:self.lbNoticeSpt];
    
    [self.viewButton addSubview:self.btnBackFirst];
    [self.viewButton addSubview:self.btnCheckOrder];
    
    __weak typeof(self)weakself = self;
    
#pragma -----------------------------------------------------------------------

    
    [self.bgScrollView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself).offset(0);
        make.left.equalTo(weakself).offset(0);
        make.right.equalTo(weakself).offset(0);
        make.bottom.equalTo(weakself).offset(0);
    }];

    [self.imgInfotitle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.bgScrollView.mas_top).offset(15);
        make.left.equalTo(weakself.bgScrollView.mas_left).offset(5);
        make.right.equalTo(weakself.bgScrollView.mas_right).offset(-5);
        make.bottom.equalTo(weakself.filmPhone.mas_bottom).offset(15);
    }];
    [self.imgInfocenter mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.imgInfotitle.mas_bottom);
        make.left.equalTo(weakself.bgScrollView.mas_left).offset(5);
        make.right.equalTo(weakself.bgScrollView.mas_right).offset(-5);
        make.bottom.equalTo(weakself.btnKeep.mas_bottom).offset(15);
    }];
    [self.imgInfofooter mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.imgInfocenter.mas_bottom).offset(15);
        make.left.equalTo(weakself.bgScrollView.mas_left).offset(5);
        make.right.equalTo(weakself.bgScrollView.mas_right).offset(-5);
        make.bottom.equalTo(weakself.lbNoticeDetail.mas_bottom).offset(15);
    }];
    [self.viewButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.imgLogo.mas_bottom).offset(20);
        make.left.equalTo(weakself.bgScrollView.mas_left).offset(0);
        make.right.equalTo(weakself.bgScrollView.mas_right).offset(0);
        make.width.equalTo(weakself.mas_width);
        make.height.equalTo(@60);
        make.bottom.equalTo(weakself.bgScrollView.mas_bottom).offset(0);
    }];
    
    
    
    
    
    
    [self.filmName mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.imgInfotitle.mas_top).offset(10);
        make.left.equalTo(weakself.imgInfotitle.mas_left).offset(10);
        make.height.equalTo(@20);
    }];
    [self.filmType mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.imgInfotitle.mas_top).offset(12);
        make.left.equalTo(weakself.filmName.mas_right).offset(10);
        make.height.equalTo(@20);
    }];
    
    
    
    
    [self.filmSeaton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.filmName.mas_bottom).offset(10);
        make.left.equalTo(weakself.imgInfotitle.mas_left).offset(10);
    }];
    [self.filmSeattw mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.filmName.mas_bottom).offset(10);
        make.left.equalTo(weakself.filmSeaton.mas_right).offset(10);
    }];
    [self.filmSeatth mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.filmName.mas_bottom).offset(10);
        make.left.equalTo(weakself.filmSeattw.mas_right).offset(10);
    }];
    [self.filmSeatfo mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.filmName.mas_bottom).offset(10);
        make.left.equalTo(weakself.filmSeatth.mas_right).offset(10);
    }];
    
    
    
    
    [self.imgInfoTime mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.filmSeaton.mas_bottom).offset(10);
        make.left.equalTo(weakself.imgInfotitle.mas_left).offset(10);
        make.height.equalTo(@20);
        make.width.equalTo(@20);
    }];
    [self.filmTime mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.filmSeaton.mas_bottom).offset(10);
        make.left.equalTo(weakself.imgInfoTime.mas_right).offset(10);
        make.height.equalTo(@20);
    }];
    
    
    [self.imgInfoAddress mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.imgInfoTime.mas_bottom).offset(10);
        make.left.equalTo(weakself.imgInfotitle.mas_left).offset(10);
        make.height.equalTo(@20);
        make.width.equalTo(@20);
    }];
    [self.filmAddress mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.imgInfoTime.mas_bottom).offset(10);
        make.left.equalTo(weakself.imgInfoAddress.mas_right).offset(10);
        make.height.equalTo(@20);
    }];
    
    
    [self.imgInfoPhone mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.imgInfoAddress.mas_bottom).offset(10);
        make.left.equalTo(weakself.imgInfotitle.mas_left).offset(10);
        make.height.equalTo(@20);
        make.width.equalTo(@20);
    }];
    [self.filmPhone mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.imgInfoAddress.mas_bottom).offset(10);
        make.left.equalTo(weakself.imgInfoPhone.mas_right).offset(10);
        make.height.equalTo(@20);
    }];

    
    
    [self.ticketCode mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.imgInfocenter.mas_top).offset(10);
        make.left.equalTo(weakself.imgInfocenter.mas_left).offset(10);
        make.right.equalTo(weakself.imgInfocenter.mas_right).offset(-10);
        make.height.equalTo(@20);
    }];
    [self.ticketNumb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.ticketCode.mas_bottom).offset(10);
        make.left.equalTo(weakself.imgInfocenter.mas_left).offset(-10);
        make.right.equalTo(weakself.imgInfocenter.mas_right).offset(10);
        make.height.equalTo(@20);
    }];
    
    
    [self.imgCodeQR mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.ticketNumb.mas_bottom).offset(10);
        make.centerX.equalTo(weakself.imgInfocenter);
        make.height.equalTo(@135);
        make.width.equalTo(@135);
    }];
    [self.imgCodeBar mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.imgCodeQR.mas_bottom).offset(10);
        make.centerX.equalTo(weakself.imgInfocenter);
        make.height.equalTo(@100);
        make.width.equalTo(@280);
    }];
    
    
    
    
    
    
    
    
    
    
    [self.lightLinelb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.imgCodeBar.mas_bottom).offset(20);
        make.left.equalTo(weakself.imgInfocenter.mas_left).offset(0);
        make.right.equalTo(weakself.imgInfocenter.mas_right).offset(0);
        make.height.equalTo(@0.5);
    }];
    
    
    
    
    [self.payDetail mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.lightLinelb.mas_bottom).offset(10);
        make.left.equalTo(weakself.imgInfocenter.mas_left).offset(10);
        make.height.equalTo(@20);
    }];
    [self.cardCount mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.payDetail.mas_bottom).offset(10);
        make.left.equalTo(weakself.imgInfocenter.mas_left).offset(10);
        make.height.equalTo(@20);
    }];
    [self.balanceCount mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.cardCount.mas_bottom).offset(10);
        make.left.equalTo(weakself.imgInfocenter.mas_left).offset(10);
        make.height.equalTo(@20);
    }];
    
    
    [self.btnKeep mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.balanceCount.mas_bottom).offset(10);
        make.left.equalTo(weakself.imgInfocenter.mas_left).offset(10);
        make.height.equalTo(@40);
    }];
    [self.btnShare mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.balanceCount.mas_bottom).offset(10);
        make.right.equalTo(weakself.imgInfocenter.mas_right).offset(-10);
        make.height.equalTo(@40);
    }];

    
    
    [self.lbNotice mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.imgInfofooter.mas_top).offset(10);
        make.left.equalTo(weakself.imgInfofooter.mas_left).offset(10);
        make.height.equalTo(@20);
    }];
    [self.lbNoticeDetail mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.lbNotice.mas_bottom).offset(10);
        make.left.equalTo(weakself.imgInfofooter.mas_left).offset(15);
        make.right.equalTo(weakself.imgInfofooter.mas_right).offset(-15);
    }];
    
    
    [self.lbPhoneNum mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.imgInfofooter.mas_bottom).offset(15);
        make.centerX.equalTo(weakself.bgScrollView.mas_centerX).offset(15);
        make.height.equalTo(@20);
    }];
    [self.imgLogophone mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.imgInfofooter.mas_bottom).offset(15);
        make.right.equalTo(weakself.lbPhoneNum.mas_left).offset(0);
        make.height.equalTo(@20);
        make.width.equalTo(@20);
    }];
    
    [self.lbNotices mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.lbPhoneNum.mas_bottom).offset(10);
        make.centerX.equalTo(weakself.bgScrollView.mas_centerX).offset(-30);
        make.height.equalTo(@20);
    }];
    [self.imgLogo mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.lbPhoneNum.mas_bottom).offset(10);
        make.left.equalTo(weakself.lbNotices.mas_right).offset(0);
        make.height.equalTo(@20);
        make.width.equalTo(@20);
    }];
    [self.lbNoticeSpt mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.lbPhoneNum.mas_bottom).offset(10);
        make.left.equalTo(weakself.imgLogo.mas_right).offset(0);
        make.height.equalTo(@20);
    }];
    
    
    
    [self.btnBackFirst mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.viewButton.mas_top);
        make.left.equalTo(weakself.viewButton.mas_left);
        make.width.equalTo(@120);
        make.height.equalTo(@60);
    }];
    [self.btnCheckOrder mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.viewButton.mas_top);
        make.right.equalTo(weakself.viewButton.mas_right);
        make.width.equalTo(@120);
        make.height.equalTo(@60);
    }];

}

- (void)setCodeModel:(TicketCodeModel *)codeModel {

    _codeModel = codeModel;

}

- (void)operateResult:(id)target action:(SEL)action {
    [self.backButton addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    [self.checkButton addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
}

- (void)gestureTap:(id)target action:(SEL)action {
    UITapGestureRecognizer * gestureOne = [[UITapGestureRecognizer alloc] initWithTarget:target action:action];
    [self.teleBackView addGestureRecognizer:gestureOne];
}

- (void)checkPrize:(id)target action:(SEL)action {
    UITapGestureRecognizer * gesture = [[UITapGestureRecognizer alloc] initWithTarget:target action:action];
    [self.prizeLabel addGestureRecognizer:gesture];
}

- (BOOL)isPureInt:(NSString*)string {
    NSScanner * scan = [NSScanner scannerWithString:string];
    int val;
    return[scan scanInt:&val] && [scan isAtEnd];
}
-(NSMutableAttributedString *)changeTextColorAction:(NSString *)text  changeColorStr:(NSString *)changeColorStr{
    //更改小标题颜色不一致
    NSMutableAttributedString * noteStr = [[NSMutableAttributedString alloc] initWithString:text];
    NSRange redRange = NSMakeRange(0, [[noteStr string] rangeOfString:changeColorStr].location);
    [noteStr addAttribute:NSForegroundColorAttributeName value:[UIColor darkGrayColor] range:redRange];
    return noteStr;
}
#pragma 新增-------------------------------------------
- (UIImageView *)imgInfotitle
{
    if (!_imgInfotitle) {
        _imgInfotitle = [UIImageView new];
        _imgInfotitle.userInteractionEnabled = YES;
        _imgInfotitle.backgroundColor = [UIColor whiteColor];
    }
    return _imgInfotitle;
}
- (UIImageView *)imgInfocenter
{
    if (!_imgInfocenter) {
        _imgInfocenter = [UIImageView new];
        _imgInfocenter.userInteractionEnabled = YES;
        _imgInfocenter.backgroundColor = [UIColor whiteColor];
    }
    return _imgInfocenter;
}
- (UIImageView *)imgInfoTime
{
    if (!_imgInfoTime) {
        _imgInfoTime = [UIImageView new];
        [_imgInfoTime setImage:[UIImage imageNamed:@"CardInfoOne"]];
    }
    return _imgInfoTime;
}
- (UIImageView *)imgInfoAddress
{
    if (!_imgInfoAddress) {
        _imgInfoAddress = [UIImageView new];
        [_imgInfoAddress setImage:[UIImage imageNamed:@"CardInfoOne"]];
    }
    return _imgInfoAddress;
}
- (UIImageView *)imgInfoPhone
{
    if (!_imgInfoPhone) {
        _imgInfoPhone = [UIImageView new];
        [_imgInfoPhone setImage:[UIImage imageNamed:@"CardInfoOne"]];
    }
    return _imgInfoPhone;
}

- (UILabel *)filmName
{
    if (!_filmName) {
        _filmName = [UILabel new];
        _filmName.font = [UIFont systemFontOfSize:18];
        _filmName.text = @"移动迷宫2";
    }
    return _filmName;
}
- (UILabel *)filmType
{
    if (!_filmType) {
        _filmType = [UILabel new];
        _filmType.font = [UIFont systemFontOfSize:14];
        [_filmType setTextColor:[UIColor lightGrayColor]];
        _filmType.text = @"英语3D";
    }
    return _filmType;
}
- (UILabel *)filmSeaton
{
    if (!_filmSeaton) {
        _filmSeaton = [UILabel new];
        _filmSeaton.font = [UIFont systemFontOfSize:13];
        [_filmSeaton setTextColor:UIColorFromRGB(kSkinColor)];
        _filmSeaton.backgroundColor = [[UIColor lightGrayColor]colorWithAlphaComponent:0.3];
        _filmSeaton.text = @"07排07座";
    }
    return _filmSeaton;
}
- (UILabel *)filmSeattw
{
    if (!_filmSeattw) {
        _filmSeattw = [UILabel new];
        _filmSeattw.font = [UIFont systemFontOfSize:13];
        [_filmSeattw setTextColor:UIColorFromRGB(kSkinColor)];
        _filmSeattw.backgroundColor = [[UIColor lightGrayColor]colorWithAlphaComponent:0.3];
        _filmSeattw.text = @"07排07座";
    }
    return _filmSeattw;
}- (UILabel *)filmSeatth
{
    if (!_filmSeatth) {
        _filmSeatth = [UILabel new];
        _filmSeatth.font = [UIFont systemFontOfSize:13];
        [_filmSeatth setTextColor:UIColorFromRGB(kSkinColor)];
        _filmSeatth.backgroundColor = [[UIColor lightGrayColor]colorWithAlphaComponent:0.3];
        _filmSeatth.text = @"07排07座";
    }
    return _filmSeatth;
}
- (UILabel *)filmSeatfo
{
    if (!_filmSeatfo) {
        _filmSeatfo = [UILabel new];
        _filmSeatfo.font = [UIFont systemFontOfSize:13];
        [_filmSeatfo setTextColor:UIColorFromRGB(kSkinColor)];
        _filmSeatfo.backgroundColor = [[UIColor lightGrayColor]colorWithAlphaComponent:0.3];
        _filmSeatfo.text = @"07排07座";
    }
    return _filmSeatfo;
}
- (UILabel *)filmTime
{
    if (!_filmTime) {
        _filmTime = [UILabel new];
        _filmTime.font = [UIFont systemFontOfSize:13];
        [_filmTime setTextColor:[UIColor darkGrayColor]];
        _filmTime.text = @"2015-10-20 20:00 周四";
    }
    return _filmTime;
}- (UILabel *)filmAddress
{
    if (!_filmAddress) {
        _filmAddress = [UILabel new];
        _filmAddress.font = [UIFont systemFontOfSize:13];
        [_filmAddress setTextColor:[UIColor darkGrayColor]];
        _filmAddress.text = @"新华国际影城大兴店  7号厅";
    }
    return _filmAddress;
}
- (UILabel *)filmPhone
{
    if (!_filmPhone) {
        _filmPhone = [UILabel new];
        _filmPhone.font = [UIFont systemFontOfSize:13];
        [_filmPhone setTextColor:[UIColor darkGrayColor]];
        _filmPhone.text = @"取票手机号 187007735672";
        
    }
    return _filmPhone;
}
- (UILabel *)ticketCode
{
    if (!_ticketCode) {
        _ticketCode = [UILabel new];
        _ticketCode.font = [UIFont systemFontOfSize:18];
        [_ticketCode setTextColor:UIColorFromRGB(kSkinColor)];
        [_ticketCode setTextAlignment:NSTextAlignmentCenter];
        _ticketCode.text = @"取票码: 93871309";
        [_ticketCode setAttributedText:[self changeTextColorAction:_ticketCode.text changeColorStr:@" "]];
        
    }
    return _ticketCode;
}
- (UILabel *)ticketNumb
{
    if (!_ticketNumb) {
        _ticketNumb = [UILabel new];
        [_ticketNumb setTextAlignment:NSTextAlignmentCenter];
        _ticketNumb.font = [UIFont systemFontOfSize:18];
        [_ticketNumb setTextColor:UIColorFromRGB(kSkinColor)];
        _ticketNumb.text = @"序列号: 8778808466706128";
        [_ticketNumb setAttributedText:[self changeTextColorAction:_ticketNumb.text changeColorStr:@" "]];
    }
    return _ticketNumb;
}

-(UILabel *)lightLinelb{

    if (!_lightLinelb) {
        _lightLinelb = [UILabel new];
        [_lightLinelb setBackgroundColor:[UIColor lightGrayColor]];
    }
    return _lightLinelb;
}
- (UILabel *)payDetail
{
    if (!_payDetail) {
        _payDetail = [UILabel new];
        _payDetail.font = [UIFont systemFontOfSize:16];
        [_payDetail setTextColor:[UIColor darkGrayColor]];
        _payDetail.text = @"支付详情";
    }
    return _payDetail;
}
- (UILabel *)cardCount
{
    if (!_cardCount) {
        _cardCount = [UILabel new];
        _cardCount.font = [UIFont systemFontOfSize:13];
        [_cardCount setTextColor:[UIColor darkGrayColor]];
        _cardCount.text = @"代金券抵扣：20元";
    }
    return _cardCount;
}
- (UILabel *)balanceCount
{
    if (!_balanceCount) {
        _balanceCount = [UILabel new];
        _balanceCount.font = [UIFont systemFontOfSize:13];
        [_balanceCount setTextColor:[UIColor darkGrayColor]];
        _balanceCount.text = @"账户余额支付：20元";
    }
    return _balanceCount;
}
- (UIButton *)btnKeep
{
    if (!_btnKeep) {
        _btnKeep = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnKeep setTitle:@"保存到相册" forState:UIControlStateNormal];
        [_btnKeep setBackgroundColor:[UIColor greenColor]];
    }
    return _btnKeep;
}
- (UIButton *)btnShare
{
    if (!_btnShare) {
        _btnShare = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnShare setTitle:@"分享给好友" forState:UIControlStateNormal];
        [_btnShare setBackgroundColor:[UIColor greenColor]];
    }
    return _btnShare;
}
- (UIImageView *)imgInfofooter
{
    if (!_imgInfofooter) {
        _imgInfofooter = [UIImageView new];
        _imgInfofooter.backgroundColor = [UIColor whiteColor];
    }
    return _imgInfofooter;
}
- (UILabel *)lbNotice
{
    if (!_lbNotice) {
        _lbNotice = [UILabel new];
        _lbNotice.font = [UIFont systemFontOfSize:18];
        [_lbNotice setTextColor:[UIColor darkGrayColor]];
        _lbNotice.text = @"温馨提示";
    }
    return _lbNotice;
}
- (UILabel *)lbNoticeDetail
{
    if (!_lbNoticeDetail) {
        _lbNoticeDetail = [UILabel new];
        _lbNoticeDetail.numberOfLines = 0;
        _lbNoticeDetail.font = [UIFont systemFontOfSize:12];
        [_lbNoticeDetail setTextColor:[UIColor darkGrayColor]];
        _lbNoticeDetail.text = @"取票兑换码即将发送到您填写的手机上，您可以通过短信、截屏方式记录取票码，也可以在(我的-我的订单-未取票)中随时查看我的订单";
    }
    return _lbNoticeDetail;
}

- (UILabel *)lbPhoneNum
{
    if (!_lbPhoneNum) {
        _lbPhoneNum = [UILabel new];
        _lbPhoneNum.font = [UIFont systemFontOfSize:13];
        [_lbPhoneNum setTextColor:UIColorFromRGB(kSkinColor)];
        _lbPhoneNum.text = @"影院电话010-87129000";
    }
    return _lbPhoneNum;
}
- (UILabel *)lbNotices
{
    if (!_lbNotices) {
        _lbNotices = [UILabel new];
        _lbNotices.font = [UIFont systemFontOfSize:13];
        [_lbNotices setTextColor:[UIColor lightGrayColor]];
        _lbNotices.text = @"本服务由影院只能营销专家";
    }
    return _lbNotices;
}
- (UILabel *)lbNoticeSpt
{
    if (!_lbNoticeSpt) {
        _lbNoticeSpt = [UILabel new];
        _lbNoticeSpt.font = [UIFont systemFontOfSize:13];
        [_lbNoticeSpt setTextColor:[UIColor lightGrayColor]];
        _lbNoticeSpt.text = @"提供";
    }
    return _lbNoticeSpt;
}
- (UIImageView *)imgLogo
{
    if (!_imgLogo) {
        _imgLogo = [UIImageView new];
        [_imgLogo setImage:[UIImage imageNamed:@"CardInfoOne"]];
    }
    return _imgLogo;
}
- (UIImageView *)imgLogophone
{
    if (!_imgLogophone) {
        _imgLogophone = [UIImageView new];
        [_imgLogophone setImage:[UIImage imageNamed:@"CardInfoOne"]];
    }
    return _imgLogophone;
}


-(UIView *)viewButton{

    if (!_viewButton) {
        _viewButton = [UIView new];
        [_viewButton setBackgroundColor:UIColorFromRGB(kSkinColor)];
    }
    return _viewButton;
}
- (UIButton *)btnBackFirst
{
    if (!_btnBackFirst) {
        _btnBackFirst = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnBackFirst setTitle:@"返回首页" forState:UIControlStateNormal];
    }
    return _btnBackFirst;
}
- (UIButton *)btnCheckOrder
{
    if (!_btnCheckOrder) {
        _btnCheckOrder = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnCheckOrder setTitle:@"查看订单" forState:UIControlStateNormal];
    }
    return _btnCheckOrder;
}
-(UIScrollView *)bgScrollView{

    if (!_bgScrollView) {
        _bgScrollView = [UIScrollView new];
        _bgScrollView.bounces = NO;
        _bgScrollView.showsHorizontalScrollIndicator = NO;
        _bgScrollView.showsVerticalScrollIndicator   = NO;
    }
    return _bgScrollView;
}

- (UIImageView *)imgCodeQR
{
    if (!_imgCodeQR) {
        _imgCodeQR = [UIImageView new];
        _imgCodeQR.backgroundColor = [UIColor redColor];
    }
    return _imgCodeQR;
}
- (UIImageView *)imgCodeBar
{
    if (!_imgCodeBar) {
        _imgCodeBar = [UIImageView new];
        _imgCodeBar.backgroundColor = [UIColor redColor];
    }
    return _imgCodeBar;
}
@end
