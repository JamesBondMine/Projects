//
//  main.m
//  Table
//
//  Created by hipiao on 2016/11/14.
//  Copyright © 2016年 James. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
