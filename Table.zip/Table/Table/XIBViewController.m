//
//  XIBViewController.m
//  Table
//
//  Created by hipiao on 2016/12/23.
//  Copyright © 2016年 James. All rights reserved.
//

#import "XIBViewController.h"
#import "FirstViewController.h"
#import "SecondViewController.h"
#import "ThirdViewController.h"
@interface XIBViewController ()<UIScrollViewDelegate>

@property (nonatomic,strong) UIScrollView * backScrollView;
@property (nonatomic,assign) NSInteger      currentPage;
@property (nonatomic,strong) UIButton     * btnOne;
@property (nonatomic,strong) UIButton     * btnTwo;
@property (nonatomic,strong) UIButton     * btnThr;
@property (nonatomic,strong) UIButton     * btnFor;



@property (nonatomic ,strong) ThirdViewController  *thirdVC;

@property (nonatomic ,strong) FirstViewController  *firstVC;

@property (nonatomic ,strong) SecondViewController *secondVC;

@property (nonatomic ,strong) UIViewController * currentVC;

@property (nonatomic ,strong) NSArray * headArray;

@property (nonatomic ,strong) UIScrollView *headScrollView;  //  顶部滚动视图
@property (nonatomic ,strong) UIScrollView *footScrollView;  //  顶部滚动视图

@property (nonatomic ,assign) UIViewAnimationOptions  opeartion;

@property (nonatomic ,strong) NSMutableArray * btnArray;

@end

@implementation XIBViewController


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil

{
    
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    
    if (self) {
        
        // Custom initialization
        
    }
    
    return self;
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"BLOCK";
    self.view.backgroundColor = [UIColor whiteColor];
    
    self.headArray = @[@"头条",@"娱乐",@"体育",@"财经",@"科技",@"NBA",@"手机"];
    
    [self createView];
    
   // [self initTableViews];
   // [self initScrollView];
}
-(void)createView{


    UIBarButtonItem * btnAction = [[UIBarButtonItem alloc] initWithTitle:@"下一页" style:UIBarButtonItemStylePlain target:self action:@selector(btnRightAction)];
    self.navigationItem.rightBarButtonItem = btnAction;
    self.navigationItem.rightBarButtonItem.tintColor = [UIColor redColor];
    


    
    
    self.footScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height-60, 320, 60)];
    self.footScrollView.contentSize = CGSizeMake(80*22, 0);
    self.footScrollView.bounces = NO;
    self.footScrollView.pagingEnabled = NO;
    [self.view addSubview:self.footScrollView];
    
    self.btnArray = [NSMutableArray array];
    
    for (int i = 0; i <22; i++) {
        UIButton * button = [UIButton buttonWithType:UIButtonTypeSystem];
        button.frame = CGRectMake(0 + i*80, 0, 80, 60);
        [button setTitle:[NSString stringWithFormat:@"动画：%i",i] forState:UIControlStateNormal];
        button.tag = i + 2001;
        [button addTarget:self action:@selector(oneAction:) forControlEvents:UIControlEventTouchUpInside];
        [self.footScrollView addSubview:button];
        [self.btnArray addObject:button];
    }
    
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    self.headScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 64, self.view.frame.size.width, 50)];
    self.headScrollView.backgroundColor = [UIColor whiteColor];
    self.headScrollView.contentSize = CGSizeMake(560, 0);
    self.headScrollView.bounces = NO;
    self.headScrollView.pagingEnabled = NO;
    [self.view addSubview:self.headScrollView];
    
    for (int i = 0; i < [self.headArray count]; i++) {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
        button.frame = CGRectMake(0 + i*80, 0, 80, 39);
        [button setTitle:[self.headArray objectAtIndex:i] forState:UIControlStateNormal];
        button.tag = i + 100;
        [button setBackgroundColor:[UIColor purpleColor]];
        [button addTarget:self action:@selector(didClickHeadButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        [self.headScrollView addSubview:button];
    }
    
    
    
    
    
    /*
     070.
     苹果新的API增加了addChildViewController方法，并且希望我们在使用addSubview时，同时调用[self addChildViewController:child]方法将sub view对应的viewController也加到当前ViewController的管理中。
     071.
     对于那些当前暂时不需要显示的subview，只通过addChildViewController把subViewController加进去；需要显示时再调用transitionFromViewController方法。将其添加进入底层的ViewController中。
     072.
     这样做的好处：
     073.
     
     074.
     1.无疑，对页面中的逻辑更加分明了。相应的View对应相应的ViewController。
     075.
     2.当某个子View没有显示时，将不会被Load，减少了内存的使用。
     076.
     3.当内存紧张时，没有Load的View将被首先释放，优化了程序的内存释放机制。
     077.
     */
    
    
    
    /**
     080.
     *  在iOS5中，ViewController中新添加了下面几个方法：
     081.
     *  addChildViewController:
     082.
     *  removeFromParentViewController
     083.
     *  transitionFromViewController:toViewController:duration:options:animations:completion:
     084.
     *  willMoveToParentViewController:
     085.
     *  didMoveToParentViewController:
     086.
     */
    
    self.firstVC = [[FirstViewController alloc] init];
    
    [self.firstVC.view setFrame:CGRectMake(0, 104, 320, 400)];
    
    [self addChildViewController:_firstVC];
    
    
    
    self.secondVC = [[SecondViewController alloc] init];
    
    [self.secondVC.view setFrame:CGRectMake(0, 104, 320, 400)];
    
    
    
    self.thirdVC = [[ThirdViewController alloc] init];
    
    [self.thirdVC.view setFrame:CGRectMake(0, 104, 320, 400)];
    
    
    
    //  默认,第一个视图(你会发现,全程就这一个用了addSubview)
    
    [self.view addSubview:self.firstVC.view];
    
    self.currentVC = self.firstVC;
}
- (void)didClickHeadButtonAction:(UIButton *)button
{
    
    //  点击处于当前页面的按钮,直接跳出
    
    if ((self.currentVC == self.firstVC && button.tag == 100)||(self.currentVC == self.secondVC && button.tag == 101.)) {
        
        return;
        
    }else{
        //  展示2个,其余一样,自行补全噢
        
        switch (button.tag) {
                
            case 100:
                
                [self replaceController:self.currentVC newController:self.firstVC];
                
                break;
                
            case 101:
                
                [self replaceController:self.currentVC newController:self.secondVC];
                
                break;
                
            case 102:
                
                [self replaceController:self.currentVC newController:self.thirdVC];
                
                break;
                
            case 103:
                
                [self replaceController:self.currentVC newController:self.secondVC];
                
                break;
                
            case 104:
                
                [self replaceController:self.currentVC newController:self.firstVC];
                
                break;
                
            case 105:
                
                [self replaceController:self.currentVC newController:self.thirdVC];
                
                break;
                
            case 106:
                
                [self replaceController:self.currentVC newController:self.firstVC];
                
                break;
                
                
            default:
                
                break;
                
        }
        
    }
    
    
    
}
//  切换各个标签内容
- (void)replaceController:(UIViewController *)oldController newController:(UIViewController *)newController
{
    /**
     145.
     *            着重介绍一下它
     146.
     *  transitionFromViewController:toViewController:duration:options:animations:completion:
     147.
     *  fromViewController      当前显示在父视图控制器中的子视图控制器
     148.
     *  toViewController        将要显示的姿势图控制器
     149.
     *  duration                动画时间(这个属性,old friend 了 O(∩_∩)O)
     150.
     *  options                 动画效果(渐变,从下往上等等,具体查看API)
     151.
     *  animations              转换过程中得动画
     152.
     *  completion              转换完成
     153.
     */

    
    [self addChildViewController:newController];
    [self transitionFromViewController:oldController toViewController:newController duration:2.0 options:self.opeartion animations:nil completion:^(BOOL finished) {
        if (finished) {
            [newController didMoveToParentViewController:self];
            
            [oldController willMoveToParentViewController:nil];
            
            [oldController removeFromParentViewController];
            
            self.currentVC = newController;
        }else{
            self.currentVC = oldController;
        }
        
    }];
    
}
- (void)initTableViews {
    FirstViewController * first = [[FirstViewController alloc] init];
    [self addChildViewController:first];
    SecondViewController * second = [[SecondViewController alloc] init];
    [self addChildViewController:second];
}
- (void)initScrollView {
    UIScrollView * scroll = [[UIScrollView alloc] initWithFrame:CGRectMake(0,0, Screenwidth, ScreenHeight-64)];
    
    scroll.frame = CGRectMake(0, 42, Screenwidth, ScreenHeight-64-42);
    scroll.contentSize = CGSizeMake(Screenwidth*3, ScreenHeight);
    scroll.backgroundColor = [UIColor clearColor];
    scroll.delegate = self;
    scroll.pagingEnabled = YES;
    scroll.bounces = NO;
    scroll.scrollEnabled = NO;
    scroll.showsHorizontalScrollIndicator = NO;
    scroll.showsVerticalScrollIndicator   = NO;
    self.backScrollView = scroll;
    [self.view addSubview:scroll];
    
    UIViewController * viewController = [self.childViewControllers firstObject];
    viewController.view.frame = CGRectMake(0, 0, Screenwidth, ScreenHeight-200);
    
    [self.backScrollView addSubview:viewController.view];
}
-(void)btnRightAction{

 
    FirstViewController * first = [[FirstViewController alloc]init];
    [self addChildViewController:first];
    
    [first.view setFrame:CGRectMake(0,0, Screenwidth, 300)];
    [self.view addSubview:first.view];
}
-(void)oneAction:(UIButton *)sender{
    [self.backScrollView setContentOffset:CGPointMake(Screenwidth * sender.tag, 0) animated:YES];
    switch (sender.tag) {
        case 2001:
            self.opeartion = UIViewAnimationOptionTransitionFlipFromBottom ;
            break;
        case 2002:
            self.opeartion = UIViewAnimationOptionTransitionFlipFromTop ;
            break;
        case 2003:
            self.opeartion = UIViewAnimationOptionTransitionCrossDissolve;
            break;
        case 2004:
            self.opeartion = UIViewAnimationOptionTransitionCurlDown ;
            break;
        case 2005:
            self.opeartion = UIViewAnimationOptionTransitionCurlUp ;              // if repeat, run animation back and forth

            break;
        case 2006:
            self.opeartion = UIViewAnimationOptionTransitionFlipFromRight;  // ignore nested duration

            break;
        case 2007:
            self.opeartion = UIViewAnimationOptionTransitionFlipFromLeft ;   // ignore nested curve

            break;
        case 2008:
           
            self.opeartion = UIViewAnimationOptionTransitionNone ;
            break;
        case 2009:
            self.opeartion = UIViewAnimationOptionCurveLinear ; // flip to/from hidden state instead of adding/removing

            break;
        case 2010:
            self.opeartion = UIViewAnimationOptionOverrideInheritedOptions ;

            break;
        case 2011:
            self.opeartion = UIViewAnimationOptionCurveEaseInOut ;           // default

            break;
        case 2012:
            self.opeartion = UIViewAnimationOptionCurveEaseIn ;

            break;
        case 2013:
            self.opeartion = UIViewAnimationOptionCurveEaseOut;

            break;
        case 2014:
            self.opeartion = UIViewAnimationOptionCurveLinear ;

            break;
        case 2015:
            self.opeartion = UIViewAnimationOptionTransitionNone ;           // default

            break;
        case 2016:
            self.opeartion = UIViewAnimationOptionTransitionFlipFromLeft ;

            break;
        case 2017:
            self.opeartion = UIViewAnimationOptionTransitionFlipFromRight;

            break;
        case 2018:
            self.opeartion = UIViewAnimationOptionTransitionCurlUp ;

            break;
        case 2019:
            self.opeartion = UIViewAnimationOptionTransitionCurlDown ;

            break;
        case 2020:
            self.opeartion = UIViewAnimationOptionTransitionCrossDissolve;

            break;
        case 2021:
            self.opeartion = UIViewAnimationOptionTransitionFlipFromTop ;

            break;
        case 2022:
            self.opeartion = UIViewAnimationOptionTransitionFlipFromBottom ;                  // repeat animation indefinitely
            
            
            break;
        default:
            
            break;
    }

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
