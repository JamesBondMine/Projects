//
//  ViewController.m
//  Table
//
//  Created by hipiao on 2016/11/14.
//  Copyright © 2016年 James. All rights reserved.
//

#import "ViewController.h"

#import "MasonryViewController.h"

#import "AppDelegate.h"

#import <objc/runtime.h>

@interface ViewController ()<UITableViewDelegate,UITableViewDataSource,UIScrollViewDelegate,UIAlertViewDelegate>
{

    int  sectIndex;
    UIView * add;
    NSMutableArray * mutBtnArray;

}
@property (nonatomic,strong) UIButton     * btnOne;
@property (nonatomic,strong) UIButton     * btnTwo;
@property (nonatomic,strong) UIButton     * btnThr;
@property (nonatomic,strong) UIButton     * btnFor;
@property (nonatomic,strong) UIButton     * btnCell;
@property (nonatomic,strong) UITableView  * customTable;
@property (nonatomic,strong) UITableView  * customTabla;
@property (nonatomic,strong) UIScrollView * scMine;
@property (nonatomic,strong) UIScrollView * customSc;
@property (nonatomic,strong) UIImageView  * imgTwoD;
@property (nonatomic,strong) UIImageView  * imgOneD;
@property (nonatomic,strong) UIView   * viewTableHeader;
@property (nonatomic,strong) NSString * mStrongString;
@property (nonatomic, copy)  NSString * mCopyString;

@end

@implementation ViewController

-(void)timeBlock{
   //  只打印  不弹窗————
    
    self.imgOneD.hidden = YES;
    
    UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"进入后台了吧" message:@"泗水关了我的应用" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
    [alert show];
    
}
-(void)newThread{
    @autoreleasepool {
        [NSTimer scheduledTimerWithTimeInterval:10 target:self selector:@selector(timeBlock) userInfo:nil repeats:YES];
        [[NSRunLoop currentRunLoop]run];
    }
}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    self.imgOneD.hidden = NO;
}
-(void)doSomething{

    int rowId = 5;
    BOOL states = NO;
    NSMutableArray * mutArray = [NSMutableArray array];
    NSString * loveStr = @"ZL|ZL|ZL|0|0|0|0|0|0|0|0|0|";
    NSString * columStr = @"ZL|ZL|ZL|1|2|3|4|5|6|7|8|9|";
    NSArray * sArray = [columStr componentsSeparatedByString:@"|"];
    NSArray * lArray = [loveStr componentsSeparatedByString:@"|"];
    for (int i = 0; i<sArray.count-1; i++) {
        NSDictionary * dic;
        if ([[lArray objectAtIndex:i] isEqual:@"ZL"]) {
              dic = @{@"columnId":@"0",@"seatesNo":[NSString stringWithFormat:@"(%i,%i)",0,0],@"st":[NSString stringWithFormat:@"%d",states]};
        }else{
            dic = @{@"columnId":[sArray objectAtIndex:i],@"seatesNo":[NSString stringWithFormat:@"(%i,%@)",rowId,[sArray objectAtIndex:i]],@"st":[NSString stringWithFormat:@"%d",states]};

        }
        [mutArray addObject:dic];
    }
    NSLog(@"____________%@",mutArray);

}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self doSomething];
    /*--------------------copy/strong------------------------*/
    // mStrongString 和 mCopyString 的指针指向了mStr。
    // 当mStr 的值改变的时候，mStrongString 会随之改变。
    // mCopyString 的值不会随着改变。
    
    NSMutableString * mStr = [NSMutableString stringWithString:@"hello"];
    self.mStrongString = mStr;
    self.mCopyString = mStr;
    NSLog(@"———————theStrongName = %@, theCopyName = %@",self.mStrongString, self.mCopyString);
    [mStr appendString:@"word"];
    NSLog(@"———————theStrongName = %@, theCopyName = %@", self.mStrongString, self.mCopyString);
    self.view.backgroundColor = [UIColor lightGrayColor];
    
     /*--------------------runtime------------------------*/
    /*我们写的代码在程序运行过程中都会被转化成runtime的C代码执行，例如[target doSomething];会被转化成objc_msgSend(target, @selector(doSomething));。
    OC中一切都被设计成了对象，我们都知道一个类被初始化成一个实例，这个实例是一个对象。实际上一个类本质上也是一个对象，在runtime中用结构体表示。
    相关的定义：*/
   
    /// 描述类中的一个方法
    typedef struct objc_method * Method;
    
    /// 实例变量
    typedef struct objc_ivar *Ivar;
    
    /// 类别Category
    typedef struct objc_category * Category;
    
    /// 类中声明的属性
    typedef struct objc_property * objc_property_t;
    
    
    //类在runtime中的表示
    struct objc_class {
        Class isa;//指针，顾名思义，表示是一个什么，
        //实例的isa指向类对象，类对象的isa指向元类
        
#if !__OBJC2__
        Class super_class;  //指向父类
        const char *name;  //类名
        long version;
        long info;
        long instance_size
        struct objc_ivar_list *ivars //成员变量列表
        struct objc_method_list **methodLists; //方法列表
        struct objc_cache *cache;//缓存
        //一种优化，调用过的方法存入缓存列表，下次调用先找缓存
        struct objc_protocol_list *protocols //协议列表
#endif
    } OBJC2_UNAVAILABLE;
    /* Use `Class` instead of `struct objc_class *` */
    
    
    
    unsigned int count;
    //获取属性列表
    objc_property_t *propertyList = class_copyPropertyList([self class], &count);
    for (unsigned int i=0; i<count; i++) {
        const char *propertyName = property_getName(propertyList[i]);
        NSLog(@"property---->%@", [NSString stringWithUTF8String:propertyName]);
    }
    
    //获取方法列表
    Method *methodList = class_copyMethodList([self class], &count);
    for (unsigned int i; i<count; i++) {
        Method method = methodList[i];
        NSLog(@"method---->%@", NSStringFromSelector(method_getName(method)));
    }
    
    //获取成员变量列表
    Ivar *ivarList = class_copyIvarList([self class], &count);
    for (unsigned int i; i<count; i++) {
        Ivar myIvar = ivarList[i];
        const char *ivarName = ivar_getName(myIvar);
        NSLog(@"Ivar---->%@", [NSString stringWithUTF8String:ivarName]);
    }
    
    //获取协议列表
    __unsafe_unretained Protocol **protocolList = class_copyProtocolList([self class], &count);
    for (unsigned int i; i<count; i++) {
        Protocol *myProtocal = protocolList[i];
        const char *protocolName = protocol_getName(myProtocal);
        NSLog(@"protocol---->%@", [NSString stringWithUTF8String:protocolName]);
    }
    

    
    [self createUi];
    CIFilter *filter = [CIFilter filterWithName:@"CIQRCodeGenerator"];
    // 2.恢复默认
    [filter setDefaults];
    // 3.给过滤器添加数据
    NSString * dataString = @"hahahahhahahahahahahahahahahahhahahahahahaahha";
    NSData   * data = [dataString dataUsingEncoding:NSUTF8StringEncoding];
    // 4.通过KVO设置滤镜inputMessage数据
    [filter setValue:data forKeyPath:@"inputMessage"];
    // 4.获取输出的二维码
    CIImage *outputImage = [filter outputImage];
    self.imgTwoD.image = [self createNonInterpolatedUIImageFormCIImage:outputImage withSize:200];
    self.imgOneD.image = [self generateBarCode:@"1234948958096" width:200 height:100];

    [[UIApplication sharedApplication]beginBackgroundTaskWithExpirationHandler:nil];
    NSThread * thread = [[NSThread alloc]initWithTarget:self selector:@selector(newThread) object:nil];
   // [thread start];
    
    
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_group_t group = dispatch_group_create();
    dispatch_group_async(group, queue, ^{ /*线程1 */
    
        NSLog(@"线程1");
    });
    dispatch_group_async(group, queue, ^{ /*线程2 */
   
       NSLog(@"线程2");
   
    });
    dispatch_group_async(group, queue, ^{ /*线程3 */
    
        NSLog(@"线程3");
    });
    dispatch_group_notify(group, dispatch_get_main_queue(), ^{
        //
        NSLog(@"线程123  全部执行完   执行这里");
    });
    
//    
//    //只输出：1 。发生主线程锁死。
//    NSLog(@"1");
//    dispatch_sync(dispatch_get_main_queue(), ^{
//        NSLog(@"2");
//    });
//    NSLog(@"3");
 
    
    NSRunLoop   *runloop = [NSRunLoop currentRunLoop];

    NSLog(@"长度为：__%i", [self lengtnSum:@"汉字爱爱字母aaa"]);
    
    
    if ([self lengtnSum:@"汉字爱爱字母哈哈哈哈aaa"]>20) {
        NSLog(@"太长了  受不了");
    }

}
-(int)lengtnSum:(NSString *)textStr{
    int lengtha = 0;
    for(int i=0; i< [textStr length];i++)
    {
        int a =[textStr characterAtIndex:i];
        if( a >0x4e00&& a <0x9fff){
            //汉字
            lengtha = lengtha+2;
        }else{
            
            lengtha= lengtha +1;
        }
    }
    return lengtha;
}
void runAddMethod(id self, SEL _cmd, NSString *string){
    NSLog(@"add C IMP %@", string);
}
+ (BOOL)resolveInstanceMethod:(SEL)sel{
    
    //给本类动态添加一个方法
    if ([NSStringFromSelector(sel) isEqualToString:@"resolveAdd:"]) {
        class_addMethod(self, sel, (IMP)runAddMethod, "v@:*");
    }
    return YES;
}

/**
 * 根据CIImage生成指定大小的UIImage
 * @param image CIImage
 * @param size 图片宽度
 */
- (UIImage *)createNonInterpolatedUIImageFormCIImage:(CIImage *)image withSize:(CGFloat) size
{
    CGRect extent = CGRectIntegral(image.extent);
    CGFloat scale = MIN(size/CGRectGetWidth(extent), size/CGRectGetHeight(extent));
    // 1.创建bitmap;
    size_t width = CGRectGetWidth(extent) * scale;
    size_t height = CGRectGetHeight(extent) * scale;
    CGColorSpaceRef cs = CGColorSpaceCreateDeviceGray();
    CGContextRef bitmapRef = CGBitmapContextCreate(nil, width, height, 8, 0, cs, (CGBitmapInfo)kCGImageAlphaNone);
    CIContext *context = [CIContext contextWithOptions:nil];
    CGImageRef bitmapImage = [context createCGImage:image fromRect:extent];
    CGContextSetInterpolationQuality(bitmapRef, kCGInterpolationNone);
    CGContextScaleCTM(bitmapRef, scale, scale);
    CGContextDrawImage(bitmapRef, extent, bitmapImage);
    // 2.保存bitmap到图片
    CGImageRef scaledImage = CGBitmapContextCreateImage(bitmapRef);
    CGContextRelease(bitmapRef);https://kyfw.12306.cn/otn/queryOrder/initNoComplete
    CGImageRelease(bitmapImage);
    return [UIImage imageWithCGImage:scaledImage];
}
-(UIImage*)generateBarCode:(NSString*)barCodeStr width:(CGFloat)width height:(CGFloat)height
{
    // 生成二维码图片
    CIImage *barcodeImage;
    NSData *data = [barCodeStr dataUsingEncoding:NSISOLatin1StringEncoding allowLossyConversion:false];
    CIFilter *filter = [CIFilter filterWithName:@"CICode128BarcodeGenerator"];
    
    [filter setValue:data forKey:@"inputMessage"];
    barcodeImage = [filter outputImage];
    // 消除模糊
    CGFloat scaleX = width / barcodeImage.extent.size.width; // extent 返回图片的frame
    CGFloat scaleY = height / barcodeImage.extent.size.height;
    CIImage *transformedImage = [barcodeImage imageByApplyingTransform:CGAffineTransformScale(CGAffineTransformIdentity, scaleX, scaleY)];
    
    return [UIImage imageWithCIImage:transformedImage];
    
}

-(void)createUi{
    
    [self.view addSubview:self.scMine];
    [self.view addSubview:self.customSc];
    [self.customSc addSubview:self.customTable];
    [self.customSc addSubview:self.customTabla];
    self.customTable.tableHeaderView = self.viewTableHeader;
    [self.viewTableHeader addSubview:self.imgTwoD];
    [self.viewTableHeader addSubview:self.imgOneD];
    
    __weak typeof(self)weakself = self;
    [self.scMine mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(weakself.view.mas_centerX);
        make.top.equalTo(weakself.view.mas_top);
        make.left.equalTo(weakself.view.mas_left).offset(0);
        make.height.equalTo(@64);
    }];
    
    [self.customSc mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(weakself.view.mas_left);
        make.right.equalTo(weakself.view.mas_right);
        make.top.equalTo(weakself.scMine.mas_bottom).offset(10);
        make.bottom.equalTo(weakself.view.mas_bottom);
    }];

   
    [self.customTable mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.customSc.mas_top);
        make.left.equalTo(weakself.customSc.mas_left);
        make.width.equalTo(weakself.view.mas_width);
        make.height.equalTo(weakself.view.mas_height).offset(-74);
        make.bottom.equalTo(weakself.customSc.mas_bottom);
    }];
    
    [self.customTabla mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.customTable.mas_top);
        make.left.equalTo(weakself.customTable.mas_right);
        make.width.equalTo(weakself.view.mas_width);
        make.height.equalTo(weakself.view.mas_height).offset(-74);
        make.right.equalTo(weakself.customSc.mas_right);
        make.bottom.equalTo(weakself.customSc.mas_bottom);
    }];
    
    
    [self.viewTableHeader mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.equalTo(weakself.customTable.mas_width);
        make.bottom.equalTo(@360);
    }];
    
    [self.customTable reloadData];
    [self.customTabla reloadData];

    
    [self.imgTwoD mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(weakself.viewTableHeader.mas_centerX);
        make.top.equalTo(weakself.viewTableHeader.mas_top).offset(20);
        make.height.equalTo(@200);
        make.width.equalTo(@200);
    }];


    [self.imgOneD mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(weakself.viewTableHeader.mas_centerX);
        make.top.equalTo(weakself.imgTwoD.mas_bottom).offset(20);
        make.bottom.equalTo(weakself.viewTableHeader.mas_bottom).offset(-20);
        make.height.equalTo(@100);
        make.width.equalTo(@300);
    }];


    self.customTable.autoresizingMask = UIViewAutoresizingFlexibleHeight |UIViewAutoresizingFlexibleWidth;
    
    //self.customTabla.tag = tableOne;
    mutBtnArray = [NSMutableArray array];
    /*-------------------------------------------------*/
    self.btnOne = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.btnOne setBackgroundColor:[UIColor redColor]];
    [self.btnOne setFrame:CGRectMake(0, 0, 60, 60)];
    [self.btnOne setTitle:@"1" forState:UIControlStateNormal];
    [self.btnOne addTarget:self action:@selector(oneAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.scMine addSubview:self.btnOne];
    self.btnOne.tag = 2001;
    [mutBtnArray addObject:self.btnOne];
    
    self.btnTwo = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.btnTwo setBackgroundColor:[UIColor greenColor]];
    [self.btnTwo setFrame:CGRectMake(60, 0, 60, 60)];
    [self.btnTwo setTitle:@"2" forState:UIControlStateNormal];
    [self.btnTwo addTarget:self action:@selector(oneAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.scMine addSubview:self.btnTwo];
    self.btnTwo.tag = 2002;
    [mutBtnArray addObject:self.btnTwo];
    
    self.btnThr = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.btnThr setBackgroundColor:[UIColor yellowColor]];
    [self.btnThr setFrame:CGRectMake(120, 0, 60, 60)];
    [self.btnThr setTitle:@"3" forState:UIControlStateNormal];
    [self.btnThr addTarget:self action:@selector(oneAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.scMine addSubview:self.btnThr];
    self.btnThr.tag = 2003;
    [mutBtnArray addObject:self.btnThr];
    
    self.btnFor = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.btnFor setBackgroundColor:[UIColor purpleColor]];
    [self.btnFor setFrame:CGRectMake(180, 0, 60, 60)];
    [self.btnFor setTitle:@"4" forState:UIControlStateNormal];
    [self.btnFor addTarget:self action:@selector(oneAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.scMine addSubview:self.btnFor];
    self.btnFor.tag = 2004;
    [mutBtnArray addObject:self.btnFor];
    
    
    self.btnCell = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.btnCell setBackgroundColor:[UIColor redColor]];
    [self.btnCell setFrame:CGRectMake(240, 0, Screenwidth-240, 60)];
    [self.btnCell setTitle:@"跳转" forState:UIControlStateNormal];
    [self.btnCell addTarget:self action:@selector(oneAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.scMine addSubview:self.btnCell];
    self.btnCell.tag = 2005;
    [mutBtnArray addObject:self.btnCell];
    
    
    //高性能圆角
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 100, 100)];
    imageView.center = self.view.center;
    UIImage *anotherImage = [UIImage imageNamed:@"a0.jpg"];
    UIGraphicsBeginImageContextWithOptions(imageView.bounds.size, NO, 1.0);
    [[UIBezierPath bezierPathWithRoundedRect:imageView.bounds
                                cornerRadius:50] addClip];
    [anotherImage drawInRect:imageView.bounds];
    imageView.image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    [self.view addSubview:imageView];
    
}
- (void)viewDidLayoutSubviews {
    
    [super viewDidLayoutSubviews];
    
    //此处需要设置barStyle，否则颜色会分成上下两层
    
}
-(void)oneAction:(UIButton *)sender{
    switch (sender.tag) {
        case 2001:
            sectIndex = 0;
            [_customSc setContentOffset:CGPointMake(0, 0) animated:YES];
            break;
        case 2002:
            sectIndex = 1;
            [_customSc setContentOffset:CGPointMake(self.view.frame.size.width, 0) animated:YES];
            break;
        case 2003:
            sectIndex = 2;
            [_customSc setContentOffset:CGPointMake(self.view.frame.size.width*2, 0) animated:YES];
            break;
        case 2004:
            sectIndex = 3;
            [_customSc setContentOffset:CGPointMake(self.view.frame.size.width*3, 0) animated:YES];
            break;
        case 2005:
        {
            MasonryViewController * mas = [[MasonryViewController alloc]init];
            [mas returnText:^(NSString *showText) {
                UILabel * ib = [[UILabel alloc]initWithFrame:CGRectMake(0, self.view.frame.size.height/2+50, self.view.frame.size.width, 30)];
                ib.text = showText;
                ib.backgroundColor = [UIColor greenColor];
                [ib setTextAlignment:NSTextAlignmentCenter];
                [self.view addSubview:ib];
            }];
            [self presentViewController:mas animated:YES completion:nil];
        }
            break;
        default:
            
            break;
    }
    [self.customTabla reloadData];
    [self.customTable reloadData];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return sectIndex+23;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    static NSString * cellId = @"cell";
    UITableViewCell * cell = [tableView  dequeueReusableCellWithIdentifier:cellId];
    if (cell == nil) {
        cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:cellId];
    }
    cell.textLabel.text = [NSString stringWithFormat:@"customTableView%i",sectIndex];

    return cell;
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    NSLog(@"________________________________________%i",(int)scrollView.contentOffset.x/(int)self.view.frame.size.width);
    
    if ((int)scrollView.contentOffset.x % (int)self.view.frame.size.width == 0) {
        int pageNumber = (int)scrollView.contentOffset.x/(int)self.view.frame.size.width;
        if (pageNumber == 0)
        {
            [scrollView setContentOffset:CGPointMake(0, 0)];
        }
        if (pageNumber %1 ==0)
        {
            [scrollView setContentOffset:CGPointMake(0, 0)];
        }
    }
}

#pragma block  练习{
-(void)blockTest{
    //（1）定义无参无返回值的Block
    void (^printBlock)() = ^(){
        printf("no number");
    };
    printBlock();
    printBlock(9);
    
    int mutiplier = 7;
    //（3）定义名为myBlock的代码块，返回值类型为int
    int (^myBlock)(int) = ^(int num){
        return num * mutiplier;
    };
    //使用定义的myBlock
    int newMutiplier = myBlock(3);
    printf("newMutiplier is %d",myBlock(3));
}

-(UIView *)viewTableHeader{
    if (!_viewTableHeader) {
        _viewTableHeader = [UIView new];
        _viewTableHeader.backgroundColor = [UIColor yellowColor];
    }
    return _viewTableHeader;
}
-(UITableView *)customTable{
    
    if (!_customTable) {
        _customTable = [UITableView new];
        _customTable.dataSource = self;
        _customTable.delegate   = self;
        _customTable.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    return _customTable;
}
-(UITableView *)customTabla{
    
    if (!_customTabla) {
        _customTabla = [UITableView new];
        _customTabla.dataSource = self;
        _customTabla.delegate   = self;
        _customTabla.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    return _customTabla;
}
-(UIScrollView *)scMine{
    
    if (!_scMine) {
        _scMine = [UIScrollView new];
        _scMine.backgroundColor = [UIColor whiteColor];
        _scMine.delegate   = self;
    }
    return _scMine;
}
-(UIScrollView *)customSc{
    
    if (!_customSc) {
        _customSc = [UIScrollView new];
        _customSc.delegate   = self;
        _customSc.backgroundColor = [UIColor purpleColor];
        _customSc.bounces = NO;
        _customSc.showsHorizontalScrollIndicator = NO;
        _customSc.userInteractionEnabled = YES;
        _customSc.pagingEnabled = YES;
    }
    return _customSc;
}
-(UIImageView *)imgTwoD{
    
    if (!_imgTwoD) {
        _imgTwoD = [UIImageView new];
    }
    return _imgTwoD;
}
-(UIImageView *)imgOneD{
    
    if (!_imgOneD) {
        _imgOneD = [UIImageView new];
    }
    return _imgOneD;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}


@end
