//
//  TestModel.m
//  Table
//
//  Created by hipiao on 2016/12/12.
//  Copyright © 2016年 James. All rights reserved.
//

#import "TestModel.h"

@implementation TestModel

@end
