//
//  SearchViewController.m
//  Table
//
//  Created by hipiao on 2016/12/19.
//  Copyright © 2016年 James. All rights reserved.
//

#import "SearchViewController.h"
#import "XIBViewController.h"

#import "AutoLabel.h"
#import "FireView.h"
// 最大存储的搜索历史 条数
#define MAX_COUNT 5

@interface SearchViewController ()
<
  UISearchBarDelegate,
  UITableViewDelegate,
  UITableViewDataSource,
  UIScrollViewDelegate
>
{

    int  k;
    BOOL isAdd;
    UILabel  * labelShow;
    BOOL hidenNoticeBtnSelect;
}
@property (nonatomic,strong)UITableView    * tabeleView;
@property (nonatomic,strong)NSMutableArray * dataArray;
@property (nonatomic,strong)NSMutableArray * advsList;
@property (nonatomic,strong)UIScrollView   * scrollView;
@property (nonatomic,strong)UIPageControl  * pagePoint;
@property (nonatomic,strong)NSTimer  * timer;

@end

@implementation SearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    isAdd  = true;
    self.view.backgroundColor = [UIColor whiteColor];
    
    self.dataArray = [[NSMutableArray alloc] init];
    
    [self initTabelView];
    
    [self initData];
    
    [self setNavTitleView];
    
    [self addView];
    
    
    [self SetupEmitter];
    
    [self addAutoLabel:@"祝甜甜天天快乐!"];
}

- (NSMutableArray *)advsList
{
    if(_advsList == nil){
        _advsList = [NSMutableArray array];
    }
    return _advsList;
}

#pragma mark -添加控件
- (void)addView{
    //添加图片
    for (int i = 0; i <= 6; i++) {
        [self.advsList addObject:[NSString stringWithFormat:@"a%d.jpg",i]];
        k++;
    }
    //添加滑动视图
    self.scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 150)];
    //设置代理这个必须的
    self.scrollView.pagingEnabled = YES;
    self.scrollView.delegate = self;
    //设置总大小也就是里面容纳的大小
    self.scrollView.contentSize = CGSizeMake(self.view.frame.size.width * self.advsList.count,self.scrollView.frame.size.height);
    [self.scrollView setBackgroundColor:[UIColor blackColor]];
    //里面的子视图跟随父视图改变大小
    [self.scrollView setAutoresizesSubviews:YES];
    //设置分页形式，这个必须设置
    [self.scrollView setPagingEnabled:NO];
    //隐藏横竖滑动块
    [self.scrollView setShowsVerticalScrollIndicator:NO];
    [self.scrollView setShowsHorizontalScrollIndicator:NO];
    self.scrollView.backgroundColor = [UIColor whiteColor];
    
    for(int i = 0; i < self.advsList.count;i++){
        UIImageView * thumbView = [[UIImageView alloc] init];
        thumbView.tag = i;
        thumbView.frame =  CGRectMake(self.view.frame.size.width  * i, 0, self.view.frame.size.width, 150);
        [thumbView setImage:[UIImage imageNamed:[self.advsList objectAtIndex:i]]];
        [self.scrollView addSubview:thumbView];
    }
    self.tabeleView.tableHeaderView = self.scrollView;
    //场景UIPageControl显示控件，并修改小点颜色
    self.pagePoint = [[UIPageControl alloc]init];
    self.pagePoint.currentPageIndicatorTintColor = [UIColor blackColor];
    self.pagePoint.pageIndicatorTintColor = [UIColor grayColor];
    self.pagePoint.frame = CGRectMake(0, self.scrollView.frame.origin.y+135, self.view.frame.size.width, self.pagePoint.bounds.size.height);
    [self.pagePoint setNumberOfPages:[self.advsList count]];
    [self.view addSubview:self.pagePoint];
    //延时加载
    [self performSelector:@selector(changeScrollowViewConsetMotherd) withObject:nil afterDelay:1];
    
    

    UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(0, self.view.frame.size.height-49, self.view.frame.size.width, 49);
    [btn addTarget:self action:@selector(ontherView) forControlEvents:UIControlEventTouchUpInside];
    btn.backgroundColor = [UIColor redColor];
    [btn setTitle:@"按钮" forState:UIControlStateNormal];
    [self.view addSubview:btn];
}
-(void)ontherView{

    XIBViewController * xib = [[XIBViewController alloc]init];

    [self.navigationController pushViewController:xib animated:YES];

}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if ((int)scrollView.contentOffset.x % (int)Screenwidth == 0) {
        
        int pageNumber = (int)scrollView.contentOffset.x/Screenwidth;
        if (pageNumber == 0)
        {
            [scrollView setContentOffset:CGPointMake(0, 0)];
        }
        if (pageNumber == k)
        {
            [scrollView setContentOffset:CGPointMake(0, 0)];
        }
    }
    if (scrollView.contentOffset.x/Screenwidth-1 < self.advsList.count&&scrollView.contentOffset.x/Screenwidth >= 1) {
    }
}

-(void)changeScrollowViewConsetMotherd{
    dispatch_source_t _timer1 = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0,dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0));
    dispatch_source_set_timer(_timer1,dispatch_walltime(NULL, 0),1*NSEC_PER_SEC, 0); //每3秒执行
    dispatch_source_set_event_handler(_timer1, ^{
        if(hidenNoticeBtnSelect){
            //倒计时结束，关闭
            dispatch_source_cancel(_timer1);
        }else{
            dispatch_async(dispatch_get_main_queue(), ^{
                if (self.scrollView.contentOffset.x/Screenwidth >= k) {
                    [self.scrollView setContentOffset:CGPointMake(0, self.scrollView.contentOffset.y)];
                }
                [self.scrollView setContentOffset:CGPointMake(self.scrollView.contentOffset.x+self.view.frame.size.width, self.scrollView.contentOffset.y) animated:YES];
                //currentScrollowPage = base_scrollView.contentOffset.x/WIDTH ;
            });
        }
    });
    dispatch_resume(_timer1);
}
/**
 *  数据初始化
 */
- (void)initData{
    //    [[SearchDBManage shareSearchDBManage] deleteAllSearchModel];
    self.dataArray = [[SearchDBManage shareSearchDBManage] selectAllSearchModel];
    if (self.dataArray.count == 0) {
        self.tabeleView.tableFooterView.hidden = YES; // 没有历史数据时隐藏
    }else{
        self.tabeleView.tableFooterView.hidden = NO; // 有历史数据时显示
    }
    [self.tabeleView reloadData];
}


/**
 *  设置导航栏搜索框
 */
- (void)setNavTitleView{
    UISearchBar *searchBar = [[UISearchBar alloc] init];
    searchBar.frame = CGRectMake(10,22,[[UIScreen mainScreen]bounds].size.width-60, 40);
    //     [searchBar setImage:[UIImage imageNamed:@"icon_search2"] forSearchBarIcon:UISearchBarIconSearch state:UIControlStateNormal];
    searchBar.delegate = self;
    //    searchBar.placeholder = @"请输入搜索内容";
    searchBar.barStyle = UIBarStyleDefault;
    searchBar.placeholder = @"发现有意思的艺似...";
    searchBar.searchBarStyle =UISearchBarStyleMinimal;
    searchBar.backgroundColor = [UIColor clearColor];
    //    searchBar.barTintColor = UIColorFromRGB(0xf7f7f7);
    self.navigationItem.titleView = searchBar;
}
/**
 *  设置搜索历史显示表格
 */
- (void)initTabelView{
    self.tabeleView = [[UITableView alloc] init];
    self.tabeleView.frame = self.view.bounds;
    self.tabeleView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tabeleView.delegate = self;
    self.tabeleView.dataSource = self;
    [self.view addSubview:self.tabeleView];
    
    if ([_tabeleView respondsToSelector:@selector(setSeparatorInset:)]) {
        [_tabeleView   setSeparatorInset:UIEdgeInsetsZero];
    }
    if ([_tabeleView respondsToSelector:@selector(setLayoutMargins:)]) {
        [_tabeleView setLayoutMargins:UIEdgeInsetsZero];
    }
    
    // 清空历史搜索按钮
    UIView *footView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 104)];
    
    UIButton *clearButton = [[UIButton alloc] init];
    clearButton.frame = CGRectMake(60, 60, self.view.frame.size.width - 120, 44);
    [clearButton setTitle:@"清空历史搜索" forState:UIControlStateNormal];
    [clearButton setTitleColor:[UIColor colorWithRed:242/256 green:242/256 blue:242/256 alpha:1] forState:UIControlStateNormal];
    clearButton.titleLabel.font = [UIFont systemFontOfSize:14];
    [clearButton addTarget:self action:@selector(clearButtonClick) forControlEvents:UIControlEventTouchDown];
    clearButton.layer.cornerRadius = 3;
    clearButton.layer.borderWidth = 0.5;
    clearButton.layer.borderColor = [UIColor colorWithRed:242/256 green:242/256 blue:242/256 alpha:1].CGColor;
    [footView addSubview:clearButton];
    
    self.tabeleView.tableFooterView = footView;
    
}
#pragma mark - UITableViewDelegate,UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return self.dataArray.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identify = @"identify";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identify];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:identify];
    }
    SearchModel *model = (SearchModel *)[self exchangeArray:self.dataArray][indexPath.row];
    cell.textLabel.text = model.keyWord;
    cell.detailTextLabel.text = model.currentTime;
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    SearchModel * model = (SearchModel *)[self exchangeArray:self.dataArray][indexPath.row];
    UIAlertView *alView = [[UIAlertView alloc] init];
    alView.title = @"选中的数据";
    alView.message = [NSString stringWithFormat:@"%@\n%@",model.keyWord,model.currentTime];
    [alView addButtonWithTitle:@"确定"];
    [_tabeleView deselectRowAtIndexPath:indexPath animated:YES];
}

/**
 *  清空搜索历史操作
 */
- (void)clearButtonClick{
    [[SearchDBManage shareSearchDBManage] deleteAllSearchModel];
    [self.dataArray removeAllObjects];
    [self.tabeleView reloadData];
}

#pragma mark - UISearchBarDelegate
- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar{
    return YES;
}// return NO to not become first responder
- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar{
    searchBar.showsCancelButton = YES;
    for(UIView *view in  [[[searchBar subviews] objectAtIndex:0] subviews]) {
        if([view isKindOfClass:[NSClassFromString(@"UINavigationButton") class]]) {
            UIButton * cancel =(UIButton *)view;
            [cancel setTitle:@"搜索" forState:UIControlStateNormal];
            cancel.titleLabel.font = [UIFont systemFontOfSize:14];
        }
    }
}// called when text starts editing
- (BOOL)searchBarShouldEndEditing:(UISearchBar *)searchBar{
    return YES;
}// return NO to not resign first responder
- (BOOL)searchBar:(UISearchBar *)searchBar shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    return YES;
}// called before text changes
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar{

    [self insterDBData:searchBar.text]; // 插入数据库
    [searchBar resignFirstResponder];
}// called when keyboard search button pressed
- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar {
    
    [self addAutoLabel:searchBar.text];
    [self insterDBData:searchBar.text]; // 插入数据库
    [searchBar resignFirstResponder];
}// called when cancel button pressed

/**
 *  获取当前时间
 *
 *  @return 当前时间
 */
- (NSString *)getCurrentTime{
    NSDate *  senddate=[NSDate date];
    NSDateFormatter  *dateformatter=[[NSDateFormatter alloc] init];
    [dateformatter setDateFormat:@"YYYY年MM月dd日HH:mm:ss"];
    NSString *  locationString=[dateformatter stringFromDate:senddate];
    return locationString;
}

/**
 *  去除数据库中已有的相同的关键词
 *
 *  @param keyword 关键词
 */
- (void)removeSameData:(NSString *)keyword{
    NSMutableArray *array = [[SearchDBManage shareSearchDBManage] selectAllSearchModel];
    [array enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        SearchModel *model = (SearchModel *)obj;
        if ([model.keyWord isEqualToString:keyword]) {
            [[SearchDBManage shareSearchDBManage] deleteSearchModelByKeyword:keyword];
        }
    }];
}

/**
 *  数组左移
 *
 *  @param array   需要左移的数组
 *  @param keyword 搜索关键字
 *
 *  @return 返回新的数组
 */
- (NSMutableArray *)moveArrayToLeft:(NSMutableArray *)array keyword:(NSString *)keyword{
    [array addObject:[SearchModel creatSearchModel:keyword currentTime:[self getCurrentTime]]];
    [array removeObjectAtIndex:0];
    return array;
}
/**
 *  数组逆序
 *
 *  @param array 需要逆序的数组
 *
 *  @return 逆序后的输出
 */
- (NSMutableArray *)exchangeArray:(NSMutableArray *)array{
    NSInteger num = array.count;
    NSMutableArray *temp = [[NSMutableArray alloc] init];
    for (NSInteger i = num - 1; i >= 0; i --) {
        [temp addObject:[array objectAtIndex:i]];
        
    }
    return temp;
}

/**
 *  多余20条数据就把第0条去除
 *
 *  @param keyword 插入数据库的模型需要的关键字
 */
- (void)moreThan20Data:(NSString *)keyword{
    // 读取数据库里面的数据
    NSMutableArray *array = [[SearchDBManage shareSearchDBManage] selectAllSearchModel];
    
    if (array.count > MAX_COUNT - 1) {
        NSMutableArray *temp = [self moveArrayToLeft:array keyword:keyword]; // 数组左移
        [[SearchDBManage shareSearchDBManage] deleteAllSearchModel]; //清空数据库
        [self.dataArray removeAllObjects];
        [self.tabeleView reloadData];
        [temp enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            SearchModel *model = (SearchModel *)obj; // 取出 数组里面的搜索模型
            [[SearchDBManage shareSearchDBManage] insterSearchModel:model]; // 插入数据库
        }];
    }
    else if (array.count <= MAX_COUNT - 1){ // 小于等于19 就把第20条插入数据库
        [[SearchDBManage shareSearchDBManage] insterSearchModel:[SearchModel creatSearchModel:keyword currentTime:[self getCurrentTime]]];
    }
}
/**
 *  关键词插入数据库
 *
 *  @param keyword 关键词
 */
- (BOOL)insterDBData:(NSString *)keyword{
    if (keyword.length == 0) {
        return NO;
    }
    else{//搜索历史插入数据库
        //先删除数据库中相同的数据
        [self removeSameData:keyword];
        //再插入数据库
        [self moreThan20Data:keyword];
        // 读取数据库里面的数据
        self.dataArray = [[SearchDBManage shareSearchDBManage] selectAllSearchModel];
        [self.tabeleView reloadData];
        return YES;
    }
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath

{
    
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}
-(void)addAutoLabel:(NSString *)text{

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        for (id layer in self.view.layer.sublayers) {
            if([layer isKindOfClass:[AutoLabel class]])
            {
                [layer removeFromSuperlayer];
            }
        }
        [AutoLabel createAnimationLayerWithString:text andRect: CGRectMake(0, 200, self.view.frame.size.width, self.view.frame.size.width) andView:self.view andFont:[UIFont boldSystemFontOfSize:30] andStrokeColor:[UIColor greenColor]];
    });
    
    //dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(8 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
       // FireView *animationView = [FireView sharedDefaultAnimationView];
       // [animationView show];
  //  });

}


- (void)snow{
    // 雪花／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／
    
    // Configure the particle emitter to the top edge of the screen
    CAEmitterLayer *snowEmitter = [CAEmitterLayer layer];
    snowEmitter.emitterPosition = CGPointMake(self.view.bounds.size.width / 2.0, -30);
    snowEmitter.emitterSize		= CGSizeMake(self.view.bounds.size.width * 2.0, 0.0);;
    
    // Spawn points for the flakes are within on the outline of the line
    snowEmitter.emitterMode		= kCAEmitterLayerOutline;
    snowEmitter.emitterShape	= kCAEmitterLayerLine;
    
    // Configure the snowflake emitter cell
    CAEmitterCell *snowflake = [CAEmitterCell emitterCell];
    
    //    随机颗粒的大小
    snowflake.scale = 0.2;
    snowflake.scaleRange = 0.5;
    
    //    缩放比列速度
    //        snowflake.scaleSpeed = 0.1;
    
    //    粒子参数的速度乘数因子；
    snowflake.birthRate		= 20.0;
    
    //生命周期
    snowflake.lifetime		= 60.0;
    
    //    粒子速度
    snowflake.velocity		= 20;				// falling down slowly
    snowflake.velocityRange = 10;
    //    粒子y方向的加速度分量
    snowflake.yAcceleration = 2;
    
    //    周围发射角度
    snowflake.emissionRange = 0.5 * M_PI;		// some variation in angle
    //    自动旋转
    snowflake.spinRange		= 0.25 * M_PI;		// slow spin
    
    snowflake.contents		= (id) [[UIImage imageNamed:@"fire"] CGImage];
    snowflake.color			= [[UIColor colorWithRed:0.600 green:0.658 blue:0.743 alpha:1.000] CGColor];
    
    // Make the flakes seem inset in the background
    snowEmitter.shadowOpacity = 1.0;
    snowEmitter.shadowRadius  = 0.0;
    snowEmitter.shadowOffset  = CGSizeMake(0.0, 1.0);
    snowEmitter.shadowColor   = [[UIColor whiteColor] CGColor];
    
    // Add everything to our backing layer below the UIContol defined in the storyboard
    snowEmitter.emitterCells = [NSArray arrayWithObject:snowflake];
    [self.view.layer addSublayer:snowEmitter];
    
    //    [self.view.layer insertSublayer:snowEmitter atIndex:0];
    //// 雪花／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／
    //// 雪花／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／／
}


- (void)SetupEmitter{
    // Cells spawn in the bottom, moving up
    CAEmitterLayer *fireworksEmitter = [CAEmitterLayer layer];
    CGRect viewBounds = self.view.layer.bounds;
    fireworksEmitter.emitterPosition = CGPointMake(viewBounds.size.width/2.0, viewBounds.size.height);
    fireworksEmitter.emitterSize	= CGSizeMake(1, 0.0);
    fireworksEmitter.emitterMode	= kCAEmitterLayerOutline;
    fireworksEmitter.emitterShape	= kCAEmitterLayerLine;
    fireworksEmitter.renderMode		= kCAEmitterLayerAdditive;
    //fireworksEmitter.seed = 500;//(arc4random()%100)+300;
    
    // Create the rocket
    CAEmitterCell* rocket = [CAEmitterCell emitterCell];
    
    rocket.birthRate		= 6.0;
    rocket.emissionRange	= 0.12 * M_PI;  // some variation in angle
    rocket.velocity			= 500;
    rocket.velocityRange	= 150;
    rocket.yAcceleration	= 0;
    rocket.lifetime			= 2.02;	// we cannot set the birthrate < 1.0 for the burst
    
    rocket.contents			= (id) [[UIImage imageNamed:@"ball"] CGImage];
    rocket.scale			= 0.2;
    //    rocket.color			= [[UIColor colorWithRed:1 green:0 blue:0 alpha:1] CGColor];
    rocket.greenRange		= 1.0;		// different colors
    rocket.redRange			= 1.0;
    rocket.blueRange		= 1.0;
    
    rocket.spinRange		= M_PI;		// slow spin
    
    
    
    // the burst object cannot be seen, but will spawn the sparks
    // we change the color here, since the sparks inherit its value
    CAEmitterCell* burst = [CAEmitterCell emitterCell];
    
    burst.birthRate			= 1.0;		// at the end of travel
    burst.velocity			= 0;
    burst.scale				= 2.5;
    burst.redSpeed			=-1.5;		// shifting
    burst.blueSpeed			=+1.5;		// shifting
    burst.greenSpeed		=+1.0;		// shifting
    burst.lifetime			= 0.35;
    
    // and finally, the sparks
    CAEmitterCell* spark = [CAEmitterCell emitterCell];
    
    spark.birthRate			= 666;
    spark.velocity			= 125;
    spark.emissionRange		= 2* M_PI;	// 360 deg
    spark.yAcceleration		= 75;		// gravity
    spark.lifetime			= 3;
    
    spark.contents			= (id) [[UIImage imageNamed:@"fire"] CGImage];
    spark.scale		        =0.5;
    spark.scaleSpeed		=-0.2;
    spark.greenSpeed		=-0.1;
    spark.redSpeed			= 0.4;
    spark.blueSpeed			=-0.1;
    spark.alphaSpeed		=-0.5;
    spark.spin				= 2* M_PI;
    spark.spinRange			= 2* M_PI;
    
    // putting it together
    fireworksEmitter.emitterCells	= [NSArray arrayWithObject:rocket];
    rocket.emitterCells				= [NSArray arrayWithObject:burst];
    burst.emitterCells				= [NSArray arrayWithObject:spark];
    [self.view.layer addSublayer:fireworksEmitter];
    
}

- (CABasicAnimation *)moveY:(float)time Y:(NSNumber *)y //纵向移动

{
    
    CABasicAnimation *animation=[CABasicAnimation animationWithKeyPath:@"transform.translation.y"];
    
    animation.toValue = y;
    
    animation.duration = time;
    
    animation.removedOnCompletion = NO;
    
    animation.fillMode = kCAFillModeForwards;
    
    return animation;
    
}


- (CAAnimation *)SetupScaleAnimation{
    CABasicAnimation *scaleAnimation = [CABasicAnimation animationWithKeyPath:@"transform.scale.y"];
    scaleAnimation.duration = 3.0;
    scaleAnimation.fromValue = [NSNumber numberWithFloat:1.0];
    scaleAnimation.toValue = [NSNumber numberWithFloat:40.0];
    //scaleAnimation.repeatCount = MAXFLOAT;
    //scaleAnimation.autoreverses = YES;
    scaleAnimation.fillMode = kCAFillModeForwards;
    scaleAnimation.removedOnCompletion = NO;
    
    return scaleAnimation;
}

- (CAAnimation *)SetupGroupAnimation{
    CAAnimationGroup *groupAnimation = [CAAnimationGroup animation];
    groupAnimation.duration = 3.0;
    groupAnimation.animations = @[[self moveY:3.0f Y:[NSNumber numberWithFloat:-300.0f]]];
    //groupAnimation.autoreverses = YES;
    //groupAnimation.repeatCount = MAXFLOAT;
    return groupAnimation;
}

- (UIImage *)imageWithColor:(UIColor *)color
{
    CGRect rect = CGRectMake(0.0f, 0.0f, 2.0f, 2.0f);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return image;
}

@end
