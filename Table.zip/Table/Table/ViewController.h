//
//  ViewController.h
//  Table
//
//  Created by hipiao on 2016/11/14.
//  Copyright © 2016年 James. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum{
    tableZero = 0,
    tableOne,
    tableTwo
} tableViewType;

@interface ViewController : UIViewController

@end

