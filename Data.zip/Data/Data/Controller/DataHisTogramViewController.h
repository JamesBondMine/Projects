//
//  DataHisTogramViewController.h
//  Data
//
//  Created by hipiao on 16/8/29.
//  Copyright © 2016年 James. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PYEchartsView.h"
#import "PYZoomEchartsView.h"


@interface DataHisTogramViewController : UIViewController

@end
