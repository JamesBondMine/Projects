//
//  PYOption.m
//  iOS-Echarts
//
//  Created by Pluto Y on 15/9/9.
//  Copyright (c) 2015年 pluto-y. All rights reserved.
//

#import "PYOption.h"

@implementation PYOption

- (instancetype)init
{
    self = [super init];
    if (self) {
        _animation = YES;
    }
    return self;
}

@end
