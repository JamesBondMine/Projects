//
//  AppDelegate.h
//  APP2
//
//  Created by hipiao. on 15/11/16.
//  Copyright (c) 2015年 hipiao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

