//
//  AppDelegate.h
//  DrawingBoard
//
//  Created by hipiao on 16/8/24.
//  Copyright © 2016年 James. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

