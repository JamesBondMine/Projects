//
//  DrawNotesViewController.h
//  DrawingBoard
//
//  Created by hipiao on 16/8/25.
//  Copyright © 2016年 James. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DrawNotesViewController : UIViewController


@property (nonatomic,strong) NSArray * pintArray;
@end
