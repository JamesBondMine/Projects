
//
//  SelectSeatsViewController.swift
//  MSF
//
//  Created by hipiao on 16/9/27.
//  Copyright © 2016年 caohan. All rights reserved.
//

import UIKit

class SelectSeatsViewController: UIViewController ,UIScrollViewDelegate{

    var seatesitem = BookingSeartesItem()
    var mutableArray = NSMutableArray()
    var mutSoldArray = NSMutableArray()
    var seatesView = BookIngSeatesView()
    var planId : NSString = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "酷炫选座"
        self.requestCinemaSeates()
        
        self.requestSeatesSold()
        
        self.createUi()
    }

    func createUi() -> Void{
        
        let cellText:UILabel = UILabel(frame:CGRect(x: 10, y: 74, width: 250, height: 20))
        cellText.font = UIFont(name:"ArialMT", size:19)
        cellText.text = "大话西游3"
        cellText.sizeToFit()
        
        
        let cellstyle:UILabel = UILabel(frame:CGRect(x: 10, y: 104, width: 60, height: 20))
        cellstyle.font = UIFont(name:"ArialMT", size:13)
        cellstyle.text = "今天"
        cellstyle.sizeToFit()
        
        
        let celldes:UILabel = UILabel(frame:CGRect(x: 80, y: 104, width: 80, height: 20))
        celldes.textColor = UIColor.lightGray
        celldes.font = UIFont(name:"ArialMT", size:13)
        celldes.text = "09月29日"
        
        
        
        let cellprice:UILabel = UILabel(frame:CGRect(x: 145, y: 104, width: 150, height: 20))
        cellprice.textColor = UIColor.red
        cellprice.font = UIFont(name:"ArialMT", size:13)
        cellprice.text = "18：40 国语 3D"
        
        
        let celltype:UILabel = UILabel(frame:CGRect(x: 0, y: 140, width: self.view.frame.width,height: 1))
        celltype.backgroundColor = UIColor.red

        let cellHall:UILabel = UILabel(frame:CGRect(x: 0, y: 175, width: self.view.frame.width, height: 25))
        cellHall.textColor = UIColor.white
        cellHall.backgroundColor = UIColor.lightGray
        cellHall.textAlignment = NSTextAlignment.center
        cellHall.text = "1号厅"
        
        
        let btnLogin:UIButton = UIButton(frame: CGRect(x: self.view.frame.size.width-70,y: 104, width: 60, height: 30))
        btnLogin.setTitle("换一场", for: UIControlState())
        btnLogin.setTitleColor(UIColor.red, for: UIControlState())
        btnLogin.layer.cornerRadius = 5
        btnLogin.layer.borderWidth  = 2
        btnLogin.layer.borderColor  = UIColor.red.cgColor
        btnLogin.addTarget(self, action: #selector(SelectSeatsViewController.changeSeatssAction), for: UIControlEvents.touchUpInside)

        
        let img1:UIImageView = UIImageView(frame:CGRect(x: (CGFloat(self.view.frame.size.width)-60*4)/5, y: 150, width: 20, height: 20))
        img1.image = UIImage(named:"unselect_seat")
        let cellLPrlce:UILabel = UILabel(frame:CGRect(x: img1.frame.origin.x+img1.frame.size.width, y: 150, width: 50, height: 20))
        cellLPrlce.textColor = UIColor.red
        cellLPrlce.font = UIFont(name:"ArialMT", size:14)
        cellLPrlce.text = "可选"
        
        let f:CGFloat = CGFloat((CGFloat(self.view.frame.size.width)-60*4)/5*2)
        let img2:UIImageView = UIImageView(frame:CGRect(x:f+60, y: 150, width: 20, height: 20))
        img2.image = UIImage(named:"unselect_seat")
        let cellLPrlce1:UILabel = UILabel(frame:CGRect(x: img2.frame.origin.x+img2.frame.size.width,y: 150, width: 50, height: 20))
        cellLPrlce1.textColor = UIColor.red
        cellLPrlce1.font = UIFont(name:"ArialMT", size:14)
        cellLPrlce1.text = "已选"
        
        let img3:UIImageView = UIImageView(frame:CGRect(x:f+CGFloat(60)*2  , y: 150, width: 20, height: 20))
        img3.image = UIImage(named:"unselect_seat")
        let cellLPrlce2:UILabel = UILabel(frame:CGRect(x: img3.frame.origin.x+img3.frame.size.width,y: 150, width: 50, height: 20))
        cellLPrlce2.textColor = UIColor.red
        cellLPrlce2.font = UIFont(name:"ArialMT", size:14)
        cellLPrlce2.text = "已售"
        
        
        let img4:UIImageView = UIImageView(frame:CGRect(x:f+CGFloat(60)*3, y: 150, width: 20, height: 20))
        img4.image = UIImage(named:"unselect_seat")
        let cellLPrlce3:UILabel = UILabel(frame:CGRect(x: img4.frame.origin.x+img4.frame.size.width,y: 150,width: 50, height: 20))
        cellLPrlce3.textColor = UIColor.red
        cellLPrlce3.font = UIFont(name:"ArialMT", size:14)
        cellLPrlce3.text = "情侣"
        
        self.view.addSubview(img1)
        self.view.addSubview(img2)
        self.view.addSubview(img3)
        self.view.addSubview(img4)
        
        self.view.addSubview(cellText)
        self.view.addSubview(cellstyle)
        self.view.addSubview(celldes)
        self.view.addSubview(cellprice)
        self.view.addSubview(celltype)
        self.view.addSubview(cellHall)
        self.view.addSubview(cellLPrlce)
        self.view.addSubview(cellLPrlce1)
        self.view.addSubview(cellLPrlce2)
        self.view.addSubview(cellLPrlce3)
        
        self.view.addSubview(btnLogin)
    }
    //根据影院ID和排期ID获取排期座位
    func requestCinemaSeates() -> Void {
        let managers = AFHTTPSessionManager()
        let urls = "http://app.vcfilm.cn/booking/getAllSeatFromVC"
        let paramss = ["token":"a3e78fbef9103c6272ebd28c3fe70709","cinemaId":"1650","platform":"5","planID":self.planId]
        managers.post(urls, parameters: paramss, progress: nil, success: { (_, JSON) in
            print("返回座位图数据为--",JSON)
            guard  ((JSON as? [String : NSObject]) != nil) else{
                print("数据返回为空!")
                return
            }
             self.seatesitem = BookingSeartesItem.mj_object(withKeyValues: JSON)
            var ar:NSArray = []
            ar = self.seatesitem.data as! NSArray;
            for index:Int in 0 ..< ar.count {
                self.seatesitem = BookingSeartesItem.mj_object(withKeyValues: ar.object(at: index))
                self.mutableArray.add(self.seatesitem)
            }

            self.seatesView = BookIngSeatesView(frame:CGRect(x: 0,y: 200,width: self.view.frame.size.width,height: 200))
            self.seatesView.btnSeates.addTarget(self, action:#selector(self.selectSeatssAction(_:)), for: UIControlEvents.touchUpInside)
            self.seatesView.scBackGround.delegate = self
            self.view.addSubview(self.seatesView)
            self.seatesView.loadSeatesAction(self.mutableArray)
            
            
            //捏合手势

            let  pinch : UIPinchGestureRecognizer = UIPinchGestureRecognizer(target:self, action:#selector(SelectSeatsViewController.pinchDetected))
            self.seatesView.scBackGround.addGestureRecognizer(pinch)
            
            
            },failure: { (_, error) in
                print(error)
        })
    }
    func pinchDetected(ges:UIPinchGestureRecognizer) -> Void {
        
        //获取缩放的比例
        let  scale:CGFloat = ges.scale;
        self.seatesView.scBackGround.transform = CGAffineTransform(scaleX: scale, y: scale);
        
    }
    func viewForZoomingInScrollView(_sc:UIScrollView) -> UIView {
        for _v:UIView in _sc.subviews {
        
            return _v;
        }
        return UIView();
    }
    func requestSeatesSold() -> Void {
        let managers = AFHTTPSessionManager()
        let urls = "http://app.vcfilm.cn//booking/getAllSeat"
        let paramss = ["token":"a3e78fbef9103c6272ebd28c3fe70709","cinemaId":"1650","platform":"5","planID":self.planId]
        managers.post(urls, parameters: paramss, progress: nil, success: { (_, JSON) in
            print("返回售出座位数据为--",JSON)
            guard  ((JSON as? [String : NSObject]) != nil) else{
                print("数据返回为空!")
                return
            }
            self.seatesitem = BookingSeartesItem.mj_object(withKeyValues: JSON)
            var ar:NSArray = []
            ar = self.seatesitem.data as! NSArray;
            for index:Int in 0 ..< ar.count {
                self.seatesitem = BookingSeartesItem.mj_object(withKeyValues: ar.object(at: index))
                self.mutSoldArray.add(self.seatesitem)
            }
            self.seatesView.loadSeatesSold(self.mutSoldArray)
            },failure: { (_, error) in
                print(error)
        })
    }
    func changeSeatssAction() -> Void {
    }
    func selectSeatssAction(_ sender:UIButton) -> Void {
        sender.setBackgroundImage(UIImage(named: "solded_seat"),for:UIControlState())
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
