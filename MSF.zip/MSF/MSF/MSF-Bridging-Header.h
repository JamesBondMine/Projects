
#import <UIImage+GIF.h>
#import <UIImageView+WebCache.h>

#import "AFNetworking.h"
#import "AFNetworkActivityIndicatorManager.h"
#import "AFNetworking/AFNetworking.h"

#import "MJExtension.h"
#import "UIView+Toast.h"


#import "UIImage+ImageEffects.h"

#import "Masonry.h"

#import "FilmDetailView.h"
#import "HP_mostColor.h"


#ifdef DEBUG
#define NSLog(format, ...) printf("\n[%s] %s [第%d行] %s\n", __TIME__, __FUNCTION__, __LINE__, [[NSString stringWithFormat:format, ## __VA_ARGS__] UTF8String]);
#else
#define NSLog(format, ...)
#endif
