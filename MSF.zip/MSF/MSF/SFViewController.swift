
//
//  SFViewController.swift
//  MSF
//
//  Created by hipiao on 16/1/14.
//  Copyright (c) 2016年 caohan. All rights reserved.
//

import UIKit


class SFViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {


    var customtableView = UITableView()
    var dataArray : NSMutableArray = []
    var adItem :FilmListItem!
    var logo = UIImageView()
    var isRefresh = Bool()
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
            //设置视图
            self.setViewController()
            //请求数据
            self.requestFilmList("110100")
    }
    func setViewController() -> Void {
        self.title="影片";
        customtableView = UITableView(frame:CGRect(x:0,y:0,width:self.view.frame.size.width,height:self.view.frame.size.height)) ;
//        customtableView.mas_makeConstraints{(make) in
//            make?.top.equalTo()(self.view)?.setOffset(64)
//            make?.bottom.equalTo()(self.view)?.setOffset(0)
//            make?.left.equalTo()(self.view)?.setOffset(0)
//            make?.right.equalTo()(self.view)?.setOffset(0)
//        }
        customtableView.backgroundColor = UIColor.lightGray
        customtableView.delegate   = self;
        customtableView.dataSource = self;
        self.view.addSubview(customtableView);
        
        logo = UIImageView(frame:CGRect(x:175,y:-80,width:40,height:40)) ;
        logo.image = UIImage(named:"57.png")
        customtableView.addSubview(logo)
    }
    func playAnimation()
    {
        //连续旋转
        UIView.beginAnimations(nil, context: nil)
        UIView.setAnimationDuration(3.0) //设置动画时间
        self.logo.transform = self.logo.transform.rotated(by: CGFloat(-M_PI/2))
        UIView.commitAnimations()
        
        //独立旋转，以初始位置旋转
        self.logo.transform = CGAffineTransform(rotationAngle: CGFloat(-M_PI/4))
    }
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        
        
        let offset:CGFloat  = scrollView.contentOffset.y
        
        if (offset < -120) {
            self.playAnimation()
             let point = CGPoint(x:0,y:offset)
            customtableView.setContentOffset(point, animated: true)
            //请求数据
            if !isRefresh {
                isRefresh = true
                self.view.makeToast("hahah")
                self.requestFilmList("110100")
            }
        }
        if (offset == -64) {
        
            isRefresh = false
        }

        print("_______________________________________________________",offset)
    }
    //根据城市ID请求热映影片
    func requestFilmList(_ cityId:NSString) -> Void {
        let managers = AFHTTPSessionManager()
        let urls = "http://app.vcfilm.cn/film/getHotFilmByCityId4App"
        let paramss = ["token":"a3e78fbef9103c6272ebd28c3fe70709","cityId":cityId,"platform":"5"]
        
        managers.post(urls, parameters: paramss, progress: nil, success: { (_, JSON) in
            let point = CGPoint(x:0,y:-64)
            self.customtableView.setContentOffset(point, animated: true)
            print(JSON)
            guard  ((JSON as? [String : NSObject]) != nil) else{
                print("数据返回为空!")
                return
            }
            let filmItem : FilmListItem = FilmListItem.mj_object(withKeyValues: JSON)
            print("________________________________",filmItem.status)
            if filmItem.status as! String == "ok"{
                let filmDataArray : NSArray!
                filmDataArray = filmItem.data as! NSArray;
                for index in 0...filmDataArray.count-1 {
                    self.adItem = FilmListItem.mj_object(withKeyValues: filmDataArray.object(at: index))
                    self.dataArray.add(self.adItem)
                }
            }
            self.customtableView.reloadData()
            },failure: { (_, error) in
                print(error)
        })
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        
        if self.dataArray.count != 0 {
            return self.dataArray.count
        }else{
            return 0
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        
        let film:FilmListItem  = self.dataArray.object(at: (indexPath as NSIndexPath).row) as! FilmListItem
        let cell: UITableViewCell = UITableViewCell(style: UITableViewCellStyle.subtitle, reuseIdentifier: "MyTestCell")
        
        
        let cellImage:UIImageView = UIImageView(frame:CGRect(x: 10, y: 10, width: 60, height: 90))
        cellImage.sd_setImage(with: URL(string:"http://img.vcfilm.cn:8080/resource/\(film.picture)"), placeholderImage: UIImage(named:"eom"))
        
        let cellText:UILabel = UILabel(frame:CGRect(x: 75, y: 10, width: 150, height: 20))
        cellText.font = UIFont(name:"ArialMT", size:14)
        cellText.text = "\(film.chname) "
        cellText.sizeToFit()
        
        let cellstyle:UILabel = UILabel(frame:CGRect(x: cellText.frame.origin.x+cellText.frame.size.width, y: 10, width: 60, height: 20))
        cellstyle.font = UIFont(name:"ArialMT", size:14)
        cellstyle.backgroundColor = UIColor.blue
        cellstyle.layer.cornerRadius = 5
        cellstyle.layer.masksToBounds = true
        cellstyle.textColor = UIColor.white
        cellstyle.font = UIFont(name:"ArialMT", size:13)
        cellstyle.text = "数字3D"
        cellstyle.sizeToFit()
        
        let celldes:UILabel = UILabel(frame:CGRect(x: 75, y: 30, width: 200, height: 20))
        celldes.textColor = UIColor.lightGray
        celldes.font = UIFont(name:"ArialMT", size:12)
        celldes.text = "\(film.onlyDescribe) "
        
        let cellprice:UILabel = UILabel(frame:CGRect(x: 75, y: 60, width: 200, height: 20))
        cellprice.textColor = UIColor.red
        cellprice.font = UIFont(name:"ArialMT", size:13)
        cellprice.text = "\(film.lprice)元起 "
        
        let celltype:UILabel = UILabel(frame:CGRect(x: 75, y: 80, width: 200, height: 20))
        celltype.textColor = UIColor.red
        celltype.font = UIFont(name:"ArialMT", size:13)
        celltype.text = "\(film.pixtype) "
        
        let btnLogin:UIButton = UIButton(frame: CGRect(x: self.view.frame.size.width-70,y: 70, width: 60, height: 30))
        btnLogin.setTitle("购票", for: UIControlState())
        btnLogin.setTitleColor(UIColor.red, for: UIControlState())
        btnLogin.layer.cornerRadius = 5
        btnLogin.layer.borderWidth  = 2
        btnLogin.layer.borderColor  = UIColor.red.cgColor
        btnLogin.addTarget(self, action: #selector(SFViewController.btnClick(_:)), for: UIControlEvents.touchUpInside)
        
        
        cell.contentView.addSubview(cellImage)
        cell.contentView.addSubview(cellText)
        cell.contentView.addSubview(cellstyle)
        cell.contentView.addSubview(celldes)
        cell.contentView.addSubview(cellprice)
        cell.contentView.addSubview(celltype)
        cell.contentView.addSubview(btnLogin)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        tableView.deselectRow(at: indexPath, animated: true)
        let film:FilmListItem  = self.dataArray.object(at: (indexPath as NSIndexPath).row) as! FilmListItem
        let detail = FilmDetailViewController();
        detail.filmId = "\(film.filmID)" as NSString
        self.navigationController?.pushViewController(detail, animated: true)
    }
    
    func btnClick(_ sender:AnyObject){
        let tow_vc = JumpViewController();
        self.navigationController?.pushViewController(tow_vc, animated: false)
    }
    
    func tableView(_ tableView: UITableView, titleForDeleteConfirmationButtonForRowAt indexPath: IndexPath) -> String?{
    
        return "删除"
    }
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool{
    
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath){
    
        if editingStyle == .delete {
            // Delete the row from the data source
            dataArray.removeObject(at: (indexPath as NSIndexPath).row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }
    }
    
    
//    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {
//        if fromIndexPath != toIndexPath{
//            var object: AnyObject = listVideos.objectAtIndex(fromIndexPath.row)
//            listVideos.removeObjectAtIndex(fromIndexPath.row)
//            if toIndexPath.row > self.listVideos.count{
//                self.listVideos.addObject(object)
//            }else{
//                self.listVideos.insertObject(object, atIndex: toIndexPath.row)
//            }
//        }
//    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
