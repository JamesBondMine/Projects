//
//  HotFilmByCinema.swift
//  MSF
//
//  Created by hipiao on 16/9/26.
//  Copyright © 2016年 caohan. All rights reserved.
//

import UIKit

class HotFilmByCinema: NSObject {

    var meg          : AnyObject = "" as AnyObject
    var status       : AnyObject = "" as AnyObject
    var data         : AnyObject = "" as AnyObject
    var playPeriod   : Int = 0
    
    
    var actorName    : NSString = ""
    var chname       : NSString = ""
    var cinemaCount  : Int = 0
    var country      : NSString = ""
    var directorName : NSString = ""
    var filmColor    : NSString = ""
    var filmID       : NSString = ""
    var filmTypeId   : Int = 0
    var fshowtime    : NSString = ""
    var gutdescipty  : NSString = ""
    var hasPlan      : Int = 0
    var lprice       : Int = 0
    var onlyDescribe : NSString = ""
    var picture      : NSString = ""
    var pixlength    : Int = 0
    var pixnumber    : Int = 0
    var pixtype      : NSString = ""
    var planCount    : Int = 0
    var playTime     : NSString = ""
    var price        : Int = 0
    var promotion    : NSString = ""
    var score        : NSString = ""
    var sellType     : Int = 0
    var showTimeMark : Int = 0
    var willDay      : Int = 0
}
