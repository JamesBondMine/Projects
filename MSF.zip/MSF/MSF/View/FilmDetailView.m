//
//  FilmDetailView.m
//  VCFilm
//
//  Created by hipiao on 16/8/12.
//  Copyright © 2016年 Hipiao. All rights reserved.
//

#import "FilmDetailView.h"
#import "Masonry.h"
#import "MSF-swift.h"
@implementation FilmDetailView

- (id)initWithFrame:(CGRect)frame{
    if ( self = [super initWithFrame:frame]) {
        self.userInteractionEnabled = YES;
        [self setselfSubviews];
    }
    return self;
}
-(void)setselfSubviews{

    
    [self addSubview:self.backButton];
    [self addSubview:self.shareButton];
    [self addSubview:self.lbTitle];

    [self.backButton mas_makeConstraints:^(MASConstraintMaker * make){
        make.top.equalTo(@30);
        make.left.equalTo(@17);
        make.height.mas_equalTo(@25);
        make.width.mas_equalTo(@22);
    }];
    [self.shareButton mas_makeConstraints:^(MASConstraintMaker * make){
        make.top.equalTo(@30);
        make.right.equalTo(@-17);
        make.height.mas_equalTo(@23);
        make.width.mas_equalTo(@20);
    }];

    [self.lbTitle mas_makeConstraints:^(MASConstraintMaker * make){
        make.top.equalTo(@30);
        make.centerX.equalTo(@0);
        make.height.mas_equalTo(@20);
        make.width.mas_equalTo(self.frame.size.width);
    }];
}
- (UIButton *)backButton
{
    if (!_backButton) {
        _backButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_backButton setImage:[UIImage imageNamed:@"button_back"] forState:UIControlStateNormal];
    }
    return _backButton;
}
- (UIButton *)shareButton
{
    if (!_shareButton) {
        _shareButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_shareButton setImage:[UIImage imageNamed:@"pbz"] forState:UIControlStateNormal];
    }
    return _shareButton;
}
- (UIView *)headerView
{
    if (!_headerView) {
        _headerView = [UIView new];
        _headerView.autoresizingMask = UIViewAutoresizingFlexibleWidth
        | UIViewAutoresizingFlexibleLeftMargin |
        UIViewAutoresizingFlexibleRightMargin;
    }
    return _headerView;
}
- (UILabel *)lbTitle
{
    if (!_lbTitle) {
        _lbTitle = [UILabel new];
        _lbTitle.text = @"影片详情";
        _lbTitle.textAlignment = NSTextAlignmentCenter;
        _lbTitle.textColor = [UIColor whiteColor];
        _lbTitle.font = [UIFont systemFontOfSize:16.f];
    }
    return _lbTitle;
}
@end
