//
//  FilmDetailView.h
//  VCFilm
//
//  Created by hipiao on 16/8/12.
//  Copyright © 2016年 Hipiao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FilmDetailView : UIView

@property (nonatomic,strong) UIButton * backButton;
@property (nonatomic,strong) UIButton * shareButton;
@property (nonatomic,strong) UIView   * headerView;
@property (nonatomic,strong) UILabel  * lbTitle;
@end
