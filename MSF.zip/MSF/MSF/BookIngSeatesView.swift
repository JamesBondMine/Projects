//
//  BookIngSeatesView.swift
//  MSF
//
//  Created by hipiao on 16/9/27.
//  Copyright © 2016年 caohan. All rights reserved.
//

import UIKit

class BookIngSeatesView: UIView {

    var scBackGround = UIScrollView()
    var lineNumArray : NSMutableArray = []
    var bestSeatArray: NSMutableArray = []
    var linCentrArray: NSMutableArray = []
    
    var btnSeates = UIButton()
    
    
    internal override init(frame: CGRect){
        super.init(frame: frame)
        
        self.backgroundColor = UIColor.lightGray;
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func loadSeatesAction(_ dataArray:NSArray) -> Void {
        
        self.scBackGround = UIScrollView(frame:CGRect(x: 0,y: 0,width: self.frame.size.width,height: self.frame.size.height))
        self.scBackGround.isScrollEnabled = true;
        self.scBackGround.showsHorizontalScrollIndicator=false;
        self.scBackGround.showsVerticalScrollIndicator=false;                                  //实现Scrollview的代理，需要在.h 文件中添加
        self.scBackGround.bounces = false;
        self.scBackGround.bouncesZoom=false;
        self.scBackGround.minimumZoomScale=1;
        self.scBackGround.maximumZoomScale=2;
        self.addSubview(self.scBackGround)
        var fx : CGFloat = 0
        var fy : CGFloat = 0
        var isSame  : Bool = true
        var isSameh : Bool = true
        for index:Int in 0...dataArray.count-1 {
            let seatesitem : BookingSeartesItem = BookingSeartesItem.mj_object(withKeyValues: dataArray.object(at: index))
            self.btnSeates = UIButton(frame:CGRect(x: CGFloat(seatesitem.xpoint)*30,y: CGFloat(seatesitem.ypoint)*25,width: 25,height: 20))
            self.btnSeates.tag = 2001;
            self.btnSeates.setBackgroundImage(UIImage(named: "unselect_seat"),for:UIControlState())

            //最佳观影座位
            if seatesitem.bestSeat == 1 {
                self.bestSeatArray.add(seatesitem)
            }
            self.scBackGround.addSubview(self.btnSeates)
            if fx < CGFloat(seatesitem.xpoint) {
                fx = CGFloat(seatesitem.xpoint)
            }
            if fy < CGFloat(seatesitem.ypoint) {
                fy = CGFloat(seatesitem.ypoint)
            }
            //无重复添加横坐标对象
           
            if self.linCentrArray.count != 0 {
                for index1:Int in 0...self.linCentrArray.count-1 {
                    if self.linCentrArray.object(at: index1) as! Int == seatesitem.xpoint {
                        isSameh = false
                    }
                }
            }
            if isSameh && seatesitem.xpoint != 0 {
                print("________________________-",seatesitem.xpoint)
                self.linCentrArray.add(seatesitem.xpoint)
                isSameh = true
            }
            //无重复添加对象
            
            if self.lineNumArray.count != 0 {
                for index1:Int in 0...self.lineNumArray.count-1 {
                    if self.lineNumArray.object(at: index1) as! Int == seatesitem.ypoint {
                        isSame = false
                    }
                }
            }
            if isSame {
                self.lineNumArray.add(seatesitem.ypoint)
                isSame = true
            }
        }
        ///处理银幕中央
        self.linCentrArray.sort(comparator: { (obj1,obj2)  in
            let result:ComparisonResult = (obj1 as! NSNumber).compare(obj2 as! NSNumber)
            return result
        })
        let lblineh : UILabel = UILabel(frame:CGRect(x:CGFloat(self.linCentrArray.lastObject as! Int)/2*30+30-3,y: 0,width: 1,height:300))
        lblineh.backgroundColor = UIColor.red
        self.scBackGround.addSubview(lblineh)

        /*----------------------------处理最佳观影区划线-------------------------------*/
        var fxmin :CGFloat = 0
        var fxmax :CGFloat = 0
        var fymin :CGFloat = 0
        var fymax :CGFloat = 0
        for index0:Int in 0...self.bestSeatArray.count-1 {
            let seatesitem : BookingSeartesItem = BookingSeartesItem.mj_object(withKeyValues: self.bestSeatArray.object(at: index0))
            if index0 == 0 {
                fxmin = CGFloat(seatesitem.xpoint)
                fxmax = CGFloat(seatesitem.xpoint)
                fymax = CGFloat(seatesitem.ypoint)
                fymin = CGFloat(seatesitem.ypoint)
            }else{
                if fxmin > CGFloat(seatesitem.xpoint) {
                    fxmin = CGFloat(seatesitem.xpoint)
                }
                if fxmax < CGFloat(seatesitem.xpoint) {
                    fxmax = CGFloat(seatesitem.xpoint)
                }
                if fymin > CGFloat(seatesitem.ypoint) {
                    fymin = CGFloat(seatesitem.ypoint)
                }
                if fymax < CGFloat(seatesitem.ypoint) {
                    fymax = CGFloat(seatesitem.ypoint)
                }
            }
        }
        fxmin = fxmin * 30
        fxmax = fxmax * 30 + 30
        fymin = fymin * 25
        fymax = fymax * 25 + 25
        let lbline1 : UILabel = UILabel(frame:CGRect(x: fxmin-3,y: fymin-3,width: fxmax-fxmin+1,height: 1))
        lbline1.backgroundColor = UIColor.black
        self.scBackGround.addSubview(lbline1)
        
        let lbline2 : UILabel = UILabel(frame:CGRect(x: fxmin-3,y: fymin-3,width: 1,height: fymax-fymin))
        lbline2.backgroundColor = UIColor.black
        self.scBackGround.addSubview(lbline2)
        
        let lbline3 : UILabel = UILabel(frame:CGRect(x: fxmin-3,y: fymax-3,width: fxmax-fxmin+1,height: 1))
        lbline3.backgroundColor = UIColor.black
        self.scBackGround.addSubview(lbline3)
        
        let lbline4 : UILabel = UILabel(frame:CGRect(x: fxmax-3,y: fymin-3,width: 1,height: fymax-fymin))
        lbline4.backgroundColor = UIColor.black
        self.scBackGround.addSubview(lbline4)
        
        //从小到大排序
        self.lineNumArray.sort(comparator: { (obj1,obj2)  in
            let result:ComparisonResult = (obj1 as! NSNumber).compare(obj2 as! NSNumber)
            return result
        })
        
        self.scBackGround.contentSize = CGSize(width: fx*30+30*2, height: fy*25+25*2)
        let lb1 : UILabel = UILabel(frame:CGRect(x: 5, y: 25,width: 15,height: fy*25))
        lb1.backgroundColor = UIColor.black;
        self.scBackGround.addSubview(lb1)
        lb1.layer.masksToBounds = true
        lb1.layer.cornerRadius = 6

        for index0:Int  in 0...self.lineNumArray.count+1{
            if index0 > 0 && CGFloat(index0) < CGFloat(self.lineNumArray.count+1) {
                let lb : UILabel = UILabel(frame:CGRect(x: 5,y: CGFloat(self.lineNumArray.object(at: index0-1) as! NSNumber)*25,width: 15,height: 20))
                lb.textColor = UIColor.white;
                lb.font = UIFont.systemFont(ofSize: 12)
                lb .text = "\(index0)"
                lb.textAlignment = NSTextAlignment.center
                self.scBackGround.addSubview(lb)
            }
        }
    }
    //加载已经售出座位
    func loadSeatesSold(_ dataArray:NSArray) -> Void {
        if dataArray.count != 0 {
            for index:Int in 0...dataArray.count-1{
                let seatesitem : BookingSeartesItem = BookingSeartesItem.mj_object(withKeyValues: dataArray.object(at: index))
                for sview:UIView in self.scBackGround.subviews {
                    if CGFloat(sview.frame.origin.x)  == CGFloat(seatesitem.columnNum)*30+90 && CGFloat(sview.frame.origin.y)  == CGFloat(seatesitem.rowNum)*25+25 {
                        (sview as! UIButton).setBackgroundImage(UIImage(named: "solded_seat"),for:UIControlState())
                        sview.isUserInteractionEnabled = false
                    }
                }
            }
        }
    }
}
