//
//  ViewController.swift
//  MSF
//
//  Created by hipiao on 16/1/12.
//  Copyright (c) 2016年 caohan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    var btnLogin     : UIButton!
    var textUserPwd  : UITextField!
    var textUserName : UITextField!
    var nullAlertViw : UIAlertView!
    
    /**
    方法体
    */
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 设置导航栏标题
        self.title="个人中心";
         self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "下一个", style: UIBarButtonItemStyle.plain, target: self, action: #selector(ViewController.next(_:)))
        
        /**
        *  创建用户名密码输入框
        */
         textUserName = UITextField(frame: CGRect(x: (self.view.frame.size.width-250)/2, y: 200, width: 250, height: 30))
        textUserName.backgroundColor = UIColor.green
        textUserName.placeholder="请输入用户名"
        self.view.addSubview(textUserName)
        
        textUserPwd = UITextField(frame: CGRect(x: (self.view.frame.size.width-250)/2, y: (vlc(textUserName))+10, width: 250, height: 30))
        textUserPwd.backgroundColor = UIColor.green
        textUserPwd.clearsOnInsertion = true
        textUserPwd.placeholder="请输入密码"
        self.view.addSubview(textUserPwd)
        
        
        btnLogin = UIButton(frame: CGRect(x: (self.view.frame.size.width-250)/2, y: (vlc(textUserPwd))+10, width: 250, height: 30))
        btnLogin.addTarget(self, action: #selector(ViewController.btnClick(_:)), for: UIControlEvents.touchUpInside)
        btnLogin.setTitle("登陆", for: UIControlState())
        btnLogin.backgroundColor = UIColor.red
        self.view.addSubview(btnLogin)
    }
    func btnClick(_ sender:AnyObject){
        if textUserName.text != ""&&textUserPwd.text != "" {
            let tow_vc = SFViewController();
            self.navigationController?.pushViewController(tow_vc, animated: true)
        }else{
            NSLog("请输入正确的用户信息")
            nullAlertViw = UIAlertView()
            nullAlertViw!.message = "请输入正确的用户信息"
            nullAlertViw!.addButton(withTitle: "确定")
            nullAlertViw!.title = "提示"
            nullAlertViw!.show()
        }
    }
    func next(_ sender: AnyObject) {
        print("跳转")
    }
    
    func vlc(_ v:UIView) -> CGFloat {
       return v.frame.size.height+v.frame.origin.y
    }
}

