//
//  JumpViewController.swift
//  MSF
//
//  Created by hipiao on 16/1/25.
//  Copyright (c) 2016年 caohan. All rights reserved.
//

import UIKit

class JumpViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UIScrollViewDelegate{

    var scBackGround = UIScrollView()
    var scDateSelect = UIScrollView()
    var scViewGround = UIScrollView()
    var customtableView = UITableView()
    var segment   =  UISegmentedControl()
    var currenDex = Int()
    var planItem  = FilmPlanItem()
    var hotfItem  = HotFilmByCinema()
    var mutableArray : NSMutableArray = []
    var lbFlmName = UILabel()
    var lbFlmType = UILabel()
    var lbFlmScor = UILabel()
    var backImage = UIImageView()
    var fiNewsWeb = UIWebView()
    var mutImageArray : NSMutableArray = []
    var showDateArray : NSMutableArray = []
    var planMutArray  : NSMutableArray = []
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
         self.title="酷炫排期";
        
        self.setUiAction()
        
        self.createUi()
        
        self.getTenDaysAction()
        
        self.requestFilmHot()
     
    }
    func getTenDaysAction() -> Void {
        /**
         *  获取当前的时间
         */
        
        let nowDate = Date()
        let formatter = DateFormatter()
        formatter.dateFormat = "MM月dd日"
       
        for index:Int  in 0...10 {
            
            let f:Double = Double(index) ;
            let date0 = nowDate.addingTimeInterval(f*24*60*60)
            let dateString2 = formatter.string(from: date0)
            showDateArray.add(dateString2)
            
        }
    }
    func setUiAction() -> Void {
        
        let btnBack = UIButton(frame:CGRect(x: 10,y: 15,width: 30,height: 20))
        btnBack.setBackgroundImage(UIImage(named: "button_back"), for: UIControlState())
        btnBack.addTarget(self, action: #selector(JumpViewController.btnClick), for: UIControlEvents.touchUpInside)
        let leftItem = UIBarButtonItem.init(customView: btnBack)
        self.navigationItem.leftBarButtonItem = leftItem
        
    }
    func btnClick() -> Void {
        
        self.navigationController?.popViewController(animated: true)
    }
    func createUi() -> Void {
        
        self.scViewGround = UIScrollView(frame:CGRect(x: 0,y: 0  ,width: self.view.frame.size.width,height: self.view.frame.size.height))
        self.scViewGround.contentSize = CGSize(width: 0, height: 2000)
        self.view.addSubview(self.scViewGround)

        let cLogo = UIImageView(frame:CGRect(x: 20, y: 10, width: 60, height: 40))
        self.scViewGround.addSubview(cLogo)
        
        let lbCinema = UILabel(frame:CGRect(x: cLogo.frame.size.width+cLogo.frame.origin.x,y: 10,width: 150,height: 40))
        lbCinema.text = "北京K酷国际影城"
        self.scViewGround.addSubview(lbCinema)
        
        let lbcAdress = UILabel(frame:CGRect(x: 10,y: cLogo.frame.size.height+cLogo.frame.origin.y,width: self.view.frame.size.width-20,height: 30))
        lbcAdress.text = "北京市东城区北苑路42号k酷时尚广场4层"
        self.scViewGround.addSubview(lbcAdress)
        
        let cMore = UIImageView(frame:CGRect(x: self.view.frame.size.width-60, y: 10, width: 20, height: 30))
        cMore.image = UIImage(named: "")
        self.scViewGround.addSubview(cMore)
        //先创建一个数组用于设置分段控件的标题
        let appsArray:[String] = ["影片排期","影片资讯"]
        self.segment = UISegmentedControl(items: appsArray)
        self.segment.frame = CGRect(x: 50,y: lbcAdress.frame.size.height+lbcAdress.frame.origin.y+20,width: self.view.frame.size.width-100,height: 30)
         self.segment.addTarget(self, action: #selector(JumpViewController.segmentChange(_:)), for: UIControlEvents.valueChanged)
        self.segment.selectedSegmentIndex = 0
        self.scViewGround.addSubview(self.segment)

        self.backImage = UIImageView(frame:CGRect(x: 0,y: self.segment.frame.origin.y+self.segment.frame.size.height+30,width: self.view.frame.size.width,height: 125))
        self.backImage.image = UIImage(named: "")
        self.backImage.isUserInteractionEnabled = true
        self.scViewGround.addSubview(self.backImage);
        
        self.scBackGround = UIScrollView(frame:CGRect(x: 0,y: self.segment.frame.origin.y+self.segment.frame.size.height+30,width: self.view.frame.size.width,height: 125))
        self.scBackGround.delegate = self
        self.scBackGround.bounces = false
        self.scBackGround.isUserInteractionEnabled = true
        self.scBackGround.backgroundColor = UIColor.clear
        self.scViewGround.addSubview(self.scBackGround)
        
        
        
        //添加影片基本信息
        self.lbFlmName = UILabel(frame:CGRect(x: 10,y: self.scBackGround.frame.origin.y+self.scBackGround.frame.size.height+10,width: 350,height: 20))
        self.lbFlmName.font = UIFont.systemFont(ofSize: 19)
        self.scViewGround.addSubview(self.lbFlmName)
        self.lbFlmName.sizeToFit()
        
        self.lbFlmType  = UILabel(frame:CGRect(x: self.lbFlmName.frame.origin.x+self.lbFlmName.frame.size.width,y: self.scBackGround.frame.origin.y+self.scBackGround.frame.size.height+10,width: 100,height: 20))
        
        self.lbFlmType.font = UIFont.systemFont(ofSize: 16)
        self.lbFlmType.backgroundColor = UIColor.red
        self.lbFlmType.layer.masksToBounds = true
        self.lbFlmType.layer.cornerRadius  = 5;
        self.lbFlmType.textColor = UIColor.white
        self.scViewGround.addSubview(self.lbFlmType)
        self.lbFlmType.sizeToFit()
        
        self.lbFlmScor = UILabel(frame:CGRect(x: self.lbFlmType.frame.origin.x+self.lbFlmType.frame.size.width,y: self.scBackGround.frame.origin.y+self.scBackGround.frame.size.height+10,width: 100,height: 20))
        
        self.lbFlmScor.font = UIFont.systemFont(ofSize: 16)
        self.scViewGround.addSubview(self.lbFlmScor)
        self.lbFlmScor.sizeToFit()

        
        //添加日期选择来加载排气数据
        self.scDateSelect = UIScrollView(frame:CGRect(x: 0,y: self.backImage.frame.origin.y+self.backImage.frame.size.height+50  ,width: self.view.frame.size.width,height: 50))
        self.scDateSelect.backgroundColor = UIColor.green
        self.scViewGround.addSubview(self.scDateSelect)

        

        self.customtableView = UITableView(frame:CGRect(x:0,y:self.scDateSelect.frame.origin.y+self.scDateSelect.frame.size.height,width:self.view.frame.size.width,height:self.view.frame.size.height)) ;
        self.customtableView.delegate   = self;
        self.customtableView.dataSource = self;
        self.customtableView.isScrollEnabled = false
        self.scViewGround.addSubview(self.customtableView);
        
        self.customtableView.backgroundColor = UIColor.yellow

        
        
        //web
        self.fiNewsWeb = UIWebView(frame:CGRect(x: 0,y: self.segment.frame.origin.y+self.segment.frame.size.height+30,width: self.view.frame.size.width,height: self.view.frame.size.height-self.segment.frame.origin.y-self.segment.frame.size.height-30-64))
        self.scViewGround.addSubview(self.fiNewsWeb)
        self.fiNewsWeb.isHidden = true
        self.fiNewsWeb .loadRequest(URLRequest(url: URL(string: "http://wx.vcfilm.cn/app/jump?from=ios&memberID=a3723a7dc78c4d0c95e50c567da5b747&versioncode=7&type=1&imei=d41d8cd98f00b204e9800998ecf8427e54c96386&md5=bb0a7e86ecd6f51a044b9ccfac546098&target=http%3A%2F%2Fwx%2Evcfilm%2Ecn%2Fcinema%2Fnoticelist%3FcinemaId%3D1987&mrId=1672356")!))
    }
    //segemnet选择改变事件
    func segmentChange(_ sender: AnyObject?)
    {
        let segment:UISegmentedControl = sender as! UISegmentedControl
        switch segment.selectedSegmentIndex {
        case 0 :
            self.fiNewsWeb.isHidden = true
            self.scViewGround.isScrollEnabled = true
            self.scBackGround.isScrollEnabled = true
            break
        case 1 :
            self.fiNewsWeb.isHidden = false
            self.scViewGround.isScrollEnabled = false
            self.scBackGround.isScrollEnabled = false
            break
        default: break
        }
    }

    //根据影院ID获取影院热映影片
    func requestFilmHot() -> Void {
        let managers = AFHTTPSessionManager()
        let urls = "http://app.vcfilm.cn/film/getHotFilmByCinemaId"
        let paramss = ["token":"a3e78fbef9103c6272ebd28c3fe70709","cinemaId":"1650","platform":"5"]
        managers.post(urls, parameters: paramss, progress: nil, success: { (_, JSON) in
            print("返回排期热映影片数据为--",JSON)
            guard  ((JSON as? [String : NSObject]) != nil) else{
                print("数据返回为空!")
                return
            }
            
            self.hotfItem = HotFilmByCinema.mj_object(withKeyValues: JSON)
            var ar:NSArray = []
             ar = self.hotfItem.data as! NSArray;
            for index:Int in 0 ..< ar.count {
                let filmHotItem: HotFilmByCinema = HotFilmByCinema.mj_object(withKeyValues: ar.object(at: index))
                print(filmHotItem.chname)
                self.mutableArray.add(filmHotItem)
            }
            self.createTableHeader(dataArray: self.mutableArray)
            },failure: { (_, error) in
                print(error)
        })
    }
    //根据影院ID获取影院排期信息
    func requestFilmPlan(curDate:NSString,filmId:NSString) -> Void {
        let managers = AFHTTPSessionManager()
        let urls = "http://app.vcfilm.cn/cinemaPlan/getFilmPlan"
        let paramss = ["token":"a3e78fbef9103c6272ebd28c3fe70709","cinemaID":"1650","platform":"5","filmId":filmId,"memberID":"0","mrId":"1672356","mgroupId":"0","curDate":curDate]
        managers.post(urls, parameters: paramss, progress: nil, success: { (_, JSON) in
            print("返回排期数据为--",JSON)
            guard  ((JSON as? [String : NSObject]) != nil) else{
                print("数据返回为空!")
                return
            }
            self.planItem = FilmPlanItem.mj_object(withKeyValues:JSON)
            print("______________________",self.planItem.meg)
            if self.planItem.status as! String == "ok"{
                let planData: FilmPlanItem = FilmPlanItem.mj_object(withKeyValues:self.planItem.data)
                var ar:NSArray = []
                ar = planData.list as! NSArray;
                self.planMutArray.removeAllObjects()
                for index:Int in 0 ..< ar.count {
                    let filmPlan = FilmPlanItem.mj_object(withKeyValues: ar.object(at: index))
                    self.planMutArray.add(filmPlan)
                }
                self.scViewGround.contentSize = CGSize(width: 0, height: CGFloat(self.planMutArray.count) * 64+400)
                self.customtableView.frame = CGRect(x: self.customtableView.frame.origin.x, y: self.customtableView.frame.origin.y, width:
                    self.customtableView.frame.size.width, height: CGFloat(self.planMutArray.count)*64)
                self.customtableView.reloadData()
            }
            },failure: { (_, error) in
                print(error)
        })
    }

    func createTableHeader(dataArray:NSArray) -> Void {
        for index:Int in 0...dataArray.count-1{
            let hotfItem0:HotFilmByCinema = HotFilmByCinema.mj_object(withKeyValues: dataArray.object(at: index))
            let str = "http://img.vcfilm.cn:8080/resource/\(hotfItem0.picture)"
            let pik:UIImageView = UIImageView(frame:CGRect(x: self.view.frame.size.width/2-35+CGFloat(index)*90, y: 10, width: 70, height: 95))
            
            pik.sd_setImage(with: URL(string:str), placeholderImage : UIImage(named:"eom"))
            
            self.scBackGround.addSubview(pik)
            let black1 = UIView(frame:CGRect(x: 0,y: 0,width: 70,height: 95))
            black1.backgroundColor = UIColor.black.withAlphaComponent(0.6)
            black1.isUserInteractionEnabled = true
            pik.addSubview(black1)
            if index == 0 {
//                pik.frame = CGRect(x: self.view.frame.size.width/2-35+CGFloat(index)*90-5, y: 5, width: 80, height: 105)
                black1.isHidden = true
            }
        }
        self.scBackGround.contentSize = CGSize(width: CGFloat(dataArray.count)*90+10+self.view.frame.size.width ,height: 0)
        let filmHotItem:HotFilmByCinema = HotFilmByCinema.mj_object(withKeyValues: self.mutableArray.object(at: 0))

        self.lbFlmScor.text = "9.6分";
        self.lbFlmType.text = "超级3D";
        self.lbFlmName.text = filmHotItem.chname as String;
        self.scDateSelect.contentSize = CGSize(width: CGFloat(showDateArray.count)*80+10,height: 0)
        
        for index:Int in 0...showDateArray.count-1{
            let lbFlmScor = UILabel(frame:CGRect(x: 10+CGFloat(index)*80,y: 10,width: 80,height: 30))
            lbFlmScor.text = showDateArray.object(at: index) as? String;
            lbFlmScor.font = UIFont.systemFont(ofSize: 14)
            self.scDateSelect.addSubview(lbFlmScor)
        }
        self.backImage.sd_setImage(with: URL(string:"http://img.vcfilm.cn:8080/resource/\(filmHotItem.picture)")) {(image, error, cacheType, url)  in
            self.backImage.image =  image?.applyBlur(withRadius: 8, tintColor: UIColor(red: 255.0/255, green: 251.0/255, blue: 240.0/255, alpha:0.12), saturationDeltaFactor: 2.0, maskImage: nil)
        }
        //根据日期和影片请求排期数据
        self.hotfItem = HotFilmByCinema.mj_object(withKeyValues: dataArray.object(at: 0))
        self.requestFilmPlan(curDate: self.hotfItem.playTime,filmId: self.hotfItem.filmID)
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        // 记录tabView的偏移量
        let offset:CGFloat  = scrollView.contentOffset.x
        var startIndex:NSInteger  = 0;
        for i:Int in 0...self.mutableArray.count
        {
            if 90 * (CGFloat(i)+1) > offset
            {
                startIndex = i;
                break;
            }
        }
        for _view:UIView in self.scBackGround.subviews {
            let point:CGPoint = CGPoint(x: _view.center.x, y: _view.center.y)
            for _view1:UIView in _view.subviews {
                UIView.animate(withDuration: 0.5, animations:{
                    if _view.frame.origin.x >= self.view.frame.size.width/2-45+CGFloat(startIndex)*90 && _view.frame.origin.x < self.view.frame.size.width/2+45+CGFloat(startIndex)*90 {
                        _view.frame = CGRect(x: _view.frame.origin.x, y: _view.frame.origin.y,width: 80, height: 105)
                        _view.center = point
                        _view1.isHidden = true
                    }else{
                        _view.frame = CGRect(x: _view.frame.origin.x, y: _view.frame.origin.y,width: 70, height: 95)
                        _view.center = point
                        _view1.isHidden = false
                        
                    }
                })
            }
        }
        if startIndex < self.mutableArray.count{
            //重新设置影片信息
            let filmHotItem:HotFilmByCinema = HotFilmByCinema.mj_object(withKeyValues: self.mutableArray.object(at: startIndex))
            self.lbFlmName.text = filmHotItem.chname as String
            self.lbFlmName.sizeToFit()
            self.lbFlmType.frame = CGRect(x: self.lbFlmName.frame.origin.x+self.lbFlmName.frame.size.width,y: self.scBackGround.frame.origin.y+self.scBackGround.frame.size.height+10,width: 100,height: 20)
            self.lbFlmType.sizeToFit()
            self.lbFlmScor.frame = CGRect(x: self.lbFlmType.frame.origin.x+self.lbFlmType.frame.size.width,y: self.scBackGround.frame.origin.y+self.scBackGround.frame.size.height+10,width: 100,height: 20)
            
            self.backImage.sd_setImage(with: URL(string:"http://img.vcfilm.cn:8080/resource/\(filmHotItem.picture)")){(image, error, cacheType, url)  in
                self.backImage.image =  image?.applyBlur(withRadius: 8, tintColor: UIColor(red: 255.0/255, green: 251.0/255, blue: 240.0/255, alpha:0.12), saturationDeltaFactor: 2.0, maskImage: nil)
            }
            let hotfItem1:HotFilmByCinema = HotFilmByCinema.mj_object(withKeyValues: self.mutableArray.object(at: startIndex))
            self.requestFilmPlan(curDate: hotfItem1.playTime,filmId: hotfItem1.filmID)
        }
    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        // 记录tabView的偏移量
        let offset:CGFloat  = scrollView.contentOffset.x
        var startIndex:NSInteger  = 0;
        for i:Int in 0...self.mutableArray.count
        {
            if 90 * (CGFloat(i)+1) > offset
            {
                startIndex = i;
                break;
            }
        }
        self.scBackGround.setContentOffset(CGPoint(x: CGFloat(startIndex)*90, y: 0), animated: true)
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        
        return self.planMutArray.count
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 64;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        
        
        let film:FilmPlanItem  = self.planMutArray.object(at: (indexPath as NSIndexPath).row) as! FilmPlanItem
        let cell: UITableViewCell = UITableViewCell(style: UITableViewCellStyle.subtitle, reuseIdentifier: "MyTestCell")
        
        
        
        let cellText:UILabel = UILabel(frame:CGRect(x: 10, y: 10, width: 50, height: 20))
        cellText.font = UIFont(name:"ArialMT", size:14)
        cellText.text = "\(film.playtime) "
        cellText.sizeToFit()
        
        
        let cellstyle:UILabel = UILabel(frame:CGRect(x: 10, y: 30, width: 60, height: 20))
        cellstyle.font = UIFont(name:"ArialMT", size:14)
        cellstyle.textColor = UIColor.white
        cellstyle.font = UIFont(name:"ArialMT", size:13)
        cellstyle.text = "\(film.endtime)结束"
        cellstyle.sizeToFit()
        
        
        let celldes:UILabel = UILabel(frame:CGRect(x: 105, y: 30, width: 50, height: 20))
        celldes.textColor = UIColor.lightGray
        celldes.font = UIFont(name:"ArialMT", size:12)
        celldes.text = "\(film.hallName) "
        
        
        let cellprice:UILabel = UILabel(frame:CGRect(x: 145, y: 10, width: 50, height: 20))
        cellprice.textColor = UIColor.red
        cellprice.font = UIFont(name:"ArialMT", size:13)
        cellprice.text = "\(film.typeName) "
        
        
        let celltype:UILabel = UILabel(frame:CGRect(x: 105, y: 10, width: 50, height: 20))
        celltype.textColor = UIColor.red
        celltype.font = UIFont(name:"ArialMT", size:13)
        celltype.text = "\(film.filmLanguage) "
        
        let cellPrice:UILabel = UILabel(frame:CGRect(x: 200, y: 30, width: 50, height: 20))
        cellPrice.textColor = UIColor.lightGray
        cellPrice.font = UIFont(name:"ArialMT", size:13)
        cellPrice.text = "\(film.price)元"
        
        let cellLPrlce:UILabel = UILabel(frame:CGRect(x: 200, y: 10, width: 50, height: 20))
        cellLPrlce.textColor = UIColor.red
        cellLPrlce.font = UIFont(name:"ArialMT", size:17)
        cellLPrlce.text = "\(film.sprice)元"

        
        let btnLogin:UIButton = UIButton(frame: CGRect(x: self.view.frame.size.width-70,y: 10, width: 60, height: 30))
        btnLogin.setTitle("购票", for: UIControlState())
        btnLogin.setTitleColor(UIColor.red, for: UIControlState())
        btnLogin.layer.cornerRadius = 5
        btnLogin.layer.borderWidth  = 2
        btnLogin.layer.borderColor  = UIColor.red.cgColor
        btnLogin.addTarget(self, action: #selector(JumpViewController.selectSeatssAction(_:)), for: UIControlEvents.touchUpInside)
        btnLogin.tag = (indexPath as NSIndexPath).row;
        
        cell.contentView.addSubview(cellText)
        cell.contentView.addSubview(cellstyle)
        cell.contentView.addSubview(celldes)
        cell.contentView.addSubview(cellprice)
        cell.contentView.addSubview(celltype)
        cell.contentView.addSubview(btnLogin)
        cell.contentView.addSubview(cellPrice)
        cell.contentView.addSubview(cellLPrlce)
        
        return cell
    }

    func selectSeatssAction(_ sender:UIButton) -> Void {
        
        let film:FilmPlanItem  = self.planMutArray.object(at: sender.tag) as! FilmPlanItem
        let tow_vc = SelectSeatsViewController();
        tow_vc.planId = "\(film.planId)" as NSString
        self.navigationController?.pushViewController(tow_vc, animated: false)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

}
