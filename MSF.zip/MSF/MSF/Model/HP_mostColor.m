//
//  HP_mostColor.m
//  VCFilm
//
//  Created by hipiao on 16/7/14.
//  Copyright © 2016年 Hipiao. All rights reserved.
//

#import "HP_mostColor.h"
#import <Accelerate/Accelerate.h>
#import "MSF-swift.h"


@implementation HP_mostColor

#pragma 根据LOGO图返回主题色 方法
+ (UIColor *)mostColorWithImage:(UIImage *)currentImage{
    
#if __IPHONE_OS_VERSION_MAX_ALLOWED > __IPHONE_6_1
    int bitmapInfo = kCGBitmapByteOrderDefault | kCGImageAlphaPremultipliedLast;
#else
    int bitmapInfo = kCGImageAlphaPremultipliedLast;
#endif
    //第一步 先把图片缩小 加快计算速度. 但越小结果误差可能越大
    CGSize thumbSize=CGSizeMake(35, 55);
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    CGContextRef context = CGBitmapContextCreate(NULL,
                                                 thumbSize.width,
                                                 thumbSize.height,
                                                 8,//bits per component
                                                 thumbSize.width*4,
                                                 colorSpace,
                                                 bitmapInfo);
    CGRect drawRect = CGRectMake(0, 0, thumbSize.width, thumbSize.height);
    CGContextDrawImage(context, drawRect, [currentImage CGImage]);
    CGColorSpaceRelease(colorSpace);
    
    //第二步 取每个点的像素值
    unsigned char* data = CGBitmapContextGetData (context);
    if (data == NULL) return nil;
    NSCountedSet *cls=[NSCountedSet setWithCapacity:thumbSize.width*thumbSize.height];
    for (int x=0; x<thumbSize.width; x++) {
        for (int y=0; y<thumbSize.height; y++) {
            int offset   = 4*(x*y);
            int red      = data[offset];
            int green    = data[offset+1];
            int blue     = data[offset+2];
            int alpha    = data[offset+3];
            NSArray *clr = @[@(red),@(green),@(blue),@(alpha)];
            [cls addObject:clr];
        }
    }
    CGContextRelease(context);
    //第三步 找到出现次数最多的那个颜色
    NSEnumerator * enumerator = [cls objectEnumerator];
    NSArray      * curColor = nil;
    NSArray      * MaxColor=nil;
    NSUInteger MaxCount=0;
    while ( (curColor = [enumerator nextObject]) != nil )
    {
        NSUInteger tmpCount = [cls countForObject:curColor];
        if ( tmpCount < MaxCount ) continue;
        MaxCount=tmpCount;
        MaxColor=curColor;
    }
    return [UIColor colorWithRed:([MaxColor[0] floatValue]/255.0f) green:([MaxColor[1] floatValue]/255.0f) blue:([MaxColor[2] floatValue]/255.0f) alpha:1];
}
+(void)chageBackGroundViewColor:(UIImage *)currentImage cview:(UIView *)cview{
    
    CAGradientLayer  * gradientLayer = [[CAGradientLayer alloc] init];
    UIColor * co = [HP_mostColor mostColorWithImage:currentImage];
    gradientLayer.colors = @[(id)[[UIColor whiteColor]colorWithAlphaComponent:0.3].CGColor,(id)co.CGColor];
    gradientLayer.startPoint = CGPointMake(0.2,0.5);
    gradientLayer.endPoint   = CGPointMake(1,1);
    gradientLayer.frame      = CGRectMake(0, 0, CGRectGetWidth(cview.frame), CGRectGetHeight(cview.frame));
    
    [cview.layer insertSublayer:gradientLayer atIndex:0];
}
//字符串判空方法
+ (BOOL)isBlankString:(NSString *)string{
    if (string == nil) {
        return YES;
    }
    if (string == NULL) {
        return YES;
    }
    if ([string isKindOfClass:[NSNull class]]) {
        return YES;
    }
    if ([[string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] length]==0) {
        return YES;
    }
    return NO;
}
//label边框设置方法
+(void)setLabelBordle:(UILabel *)lbSelf{
    [lbSelf setTextAlignment:NSTextAlignmentCenter];
    [lbSelf.layer setBorderWidth:1];//设置边界的宽度
    lbSelf.layer.cornerRadius  = 10;
    lbSelf.layer.masksToBounds = YES;
    lbSelf.layer.borderColor   = [[[UIColor lightGrayColor]colorWithAlphaComponent:0.6] CGColor];
}

//label创建方法集成
+(UILabel *)createBtn:(CGFloat)x y:(CGFloat)y w:(CGFloat)with h:(CGFloat)heigth supView:(UIView*)currentView text:(NSString *)Str font:(CGFloat)font{
    UILabel *  customLabel = [[UILabel alloc]initWithFrame:CGRectMake(x, y, with, heigth)];
    customLabel.text = Str;
    customLabel.textColor = [UIColor lightGrayColor];
    customLabel.font = [UIFont systemFontOfSize:font];
    [currentView addSubview:customLabel];
    return customLabel;
}

//添加 /
+(NSString *)setStrFine:(NSArray *)arrStr{
    NSMutableString *typeString=[NSMutableString string];
    for (int i=0; i<arrStr.count; i++) {
        [typeString appendString:[arrStr objectAtIndex:i]];
        if (i!=arrStr.count-1) {
            [typeString appendString:@" / "];
        }
    }
    return typeString;
}
+(void)setlbVerticalSpacing:(NSString *)str lb:(UILabel *)lb{

    NSMutableParagraphStyle   * paragraphStyle   = [[NSMutableParagraphStyle alloc] init];
    NSMutableAttributedString * attributedString = [[NSMutableAttributedString alloc] initWithString:str];
    [paragraphStyle setLineSpacing:6];
    [attributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, [str length])];
    lb.attributedText = attributedString;
}
#pragma 设置行距并且自适应高度 方法
+(CGRect *)returnlbVerticalSpacing:(UILabel *)lb{
    
    lb.numberOfLines = 0;
    lb.lineBreakMode = NSLineBreakByWordWrapping;
    CGSize size = [lb sizeThatFits:CGSizeMake(lb.frame.size.width, MAXFLOAT)];
    CGRect frame = lb.frame;
    frame.size.height = size.height;
    lb.frame = frame;
    
    // 设置label的行间距
    NSMutableParagraphStyle   * paragraphStyle   = [[NSMutableParagraphStyle alloc] init];
    NSMutableAttributedString * attributedString = [[NSMutableAttributedString alloc] initWithString:lb.text];
    [paragraphStyle setLineSpacing:6];
    [attributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, [lb.text length])];
    [lb setAttributedText:attributedString];
    [lb sizeToFit];
    
    return &frame;
}
+(NSArray *)setRealArray:(NSArray *)oldArray{
    
    NSMutableArray * newArray = [NSMutableArray array];
    for (int i = 0; i<oldArray.count; i++) {
        if (![[oldArray objectAtIndex:i] isEqual:@""]) {
            [newArray addObject:[oldArray objectAtIndex:i]];
        }
    }
    return newArray;
}
@end
