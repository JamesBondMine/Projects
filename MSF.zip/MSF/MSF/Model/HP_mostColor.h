//
//  HP_mostColor.h
//  VCFilm
//
//  Created by hipiao on 16/7/14.
//  Copyright © 2016年 Hipiao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HP_mostColor : NSObject

+(void)setLabelBordle:(UILabel *)lbSelf;

+ (BOOL)isBlankString:(NSString *)string;

+(NSString *)setStrFine:(NSArray *)arrStr;

+(NSArray *)setRealArray:(NSArray *)oldArray;

+(CGRect *)returnlbVerticalSpacing:(UILabel *)lb;

+(UIColor *)mostColorWithImage:(UIImage *)currentImage;

+(void)setlbVerticalSpacing:(NSString *)str lb:(UILabel *)lb;

+(void)chageBackGroundViewColor:(UIImage *)currentImage cview:(UIView *)cview;

+(UILabel *)createBtn:(CGFloat)x y:(CGFloat)y w:(CGFloat)with h:(CGFloat)heigth supView:(UIView*)currentView text:(NSString *)Str font:(CGFloat)font;


@end
