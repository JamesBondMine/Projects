


//
//  FilmDetailViewController.swift
//  MSF
//
//  Created by hipiao on 16/9/13.
//  Copyright © 2016年 caohan. All rights reserved.
//

import UIKit


class FilmDetailViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    var customtableView = UITableView()
    var dataArray:NSMutableArray = []
    var filmId:NSString = ""
    var backWriteView = UIView()
    var backBlackView = UIView()
    var backgroudView = UIView()
    var backWite1View = UIView()
    var backWite2View = UIView()
    var infoItem = FilmInfoItem()
    var headerView = FilmDetailView()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "影片详情"
        self.view.backgroundColor = UIColor.white
        self.navigationController?.isNavigationBarHidden=true
        
        self.createUi()
        self.requestFilmDetail(self.filmId)
    }
    func createUi() -> Void {

        
        self.customtableView = UITableView(frame:CGRect(x:0,y:0,width:self.view.frame.size.width,height:self.view.frame.size.height)) ;
        self.customtableView.delegate   = self;
        self.customtableView.dataSource = self;
        self.view.addSubview(self.customtableView);
        
        
        self.headerView = FilmDetailView(frame:CGRect(x:0,y:0,width:self.view.frame.size.width,height:64))
        self.headerView.backButton.addTarget(self, action:#selector(FilmDetailViewController.btnClick), for: UIControlEvents.touchUpInside)
        self.view.addSubview(self.headerView)
    }
    
    //根据影片ID请求热映影片详情
    func requestFilmDetail(_ filmId:NSString) -> Void {
        let managers = AFHTTPSessionManager()
        let urls = "http://app.vcfilm.cn/film/viewFilmInfo"
        let paramss = ["token":"a3e78fbef9103c6272ebd28c3fe70709","filmID":filmId,"platform":"5"]
        
        managers.post(urls, parameters: paramss, progress: nil, success: { (_, JSON) in
            print(JSON)
            guard  ((JSON as? [String : NSObject]) != nil) else{
                print("数据返回为空!")
                return
            }
            
            self.createFilmInfoUi(JSON! as AnyObject)
            
            },failure: { (_, error) in
                print(error)
        })
        
    }
    func createFilmInfoUi(_ json:AnyObject) -> Void {
        
        self.infoItem = FilmInfoItem.mj_object(withKeyValues: json)
        let filmItem : FilmInfoItem = FilmInfoItem.mj_object(withKeyValues: self.infoItem.filmInfo)
        self.backgroudView = UIView(frame:CGRect(x:0,y:0, width: self.view.frame.size.width, height:600));
        self.backWriteView = UIView(frame:CGRect(x:0,y:0, width: self.view.frame.size.width, height:300));
        self.backBlackView = UIView(frame:CGRect(x:0,y:-180,width:self.view.frame.size.width,height:364));
        self.backWite1View = UIView(frame:CGRect(x:0,y:320,width: self.view.frame.size.width,height:120));
        self.backWite2View = UIView(frame:CGRect(x:0,y:460,width: self.view.frame.size.width,height:120));
        self.backgroudView.backgroundColor = UIColor.lightGray
        self.backWriteView.backgroundColor = UIColor.white
        self.backWite1View.backgroundColor = UIColor.white
        self.backWite2View.backgroundColor = UIColor.white
        self.customtableView.tableHeaderView = self.backgroudView
        self.backgroudView.addSubview(self.backWite1View)
        self.backgroudView.addSubview(self.backWriteView)
        self.backWriteView.addSubview(self.backBlackView)
        self.backgroudView.addSubview(self.backWite2View)
        
        
        let backImage:UIImageView = UIImageView(frame:self.backBlackView .bounds)
        self.backBlackView.addSubview(backImage)
        
        let logoImage:UIImageView = UIImageView(frame:CGRect(x: 10, y: 234, width: 80, height: 110))
        self.backBlackView.addSubview(logoImage)
        logoImage.sd_setImage(with:NSURL(string:"http://img.vcfilm.cn:8080/resource/\(filmItem.picture)" as String)! as URL){ (image, error, cacheType, url ) in
            backImage.image = image?.applyBlur(withRadius: 8, tintColor: UIColor(red: 255.0/255, green: 251.0/255, blue: 240.0/255, alpha:0.12), saturationDeltaFactor: 2.0, maskImage: nil)
        }
        
        let cellText:UILabel = UILabel(frame:CGRect(x: 100, y: 234, width: 150, height: 20))
        cellText.font = UIFont(name:"ArialMT", size:18)
        cellText.textColor = UIColor.white
        cellText.text = "\(filmItem.filmName)"
        cellText.sizeToFit()
        
        
        let celldes:UILabel = UILabel(frame:CGRect(x: 100,y: cellText.frame.size.height+cellText.frame.origin.y, width: 200, height: 20))
        celldes.textColor = UIColor.lightGray
        celldes.font = UIFont(name:"ArialMT", size:12)
        celldes.textColor = UIColor.white
        celldes.text = "\(filmItem.onlyDescribe)"
        
        let cellstyle:UILabel = UILabel(frame:CGRect(x: 100, y: 234+45, width: 60, height: 20))
        cellstyle.font = UIFont(name:"ArialMT", size:14)
        cellstyle.textColor = UIColor.white
        cellstyle.font = UIFont(name:"ArialMT", size:13)
        cellstyle.text = "\(filmItem.score)分"
        cellstyle.sizeToFit()
        
        let celltype:UILabel = UILabel(frame:CGRect(x: 100, y: 234+60, width: 200, height: 20))
        celltype.textColor = UIColor.red
        celltype.font = UIFont(name:"ArialMT", size:13)
        celltype.textColor = UIColor.white
        celltype.text = "\(filmItem.pixtype)"
        
        
        let cellprice:UILabel = UILabel(frame:CGRect(x: 100, y: 234+75, width: 200, height: 20))
        cellprice.textColor = UIColor.white
        cellprice.font = UIFont(name:"ArialMT", size:13)
        cellprice.text = "\(filmItem.country)/\(filmItem.pixlength)分钟"
        
        
        let celltime:UILabel = UILabel(frame:CGRect(x: 100, y: 234+90, width: 200, height: 20))
        celltime.textColor = UIColor.red
        celltime.font = UIFont(name:"ArialMT", size:13)
        celltime.textColor = UIColor.white
        celltime.text = "\(filmItem.fshowtime)上映 "
        
        
        let btnLogin:UIButton = UIButton(frame: CGRect(x: self.view.frame.size.width-90,y: 234+85, width: 80, height: 25))
        btnLogin.setTitle("购票", for: UIControlState())
        btnLogin.setTitleColor(UIColor.white, for: UIControlState())
        btnLogin.layer.cornerRadius = 5
        btnLogin.layer.borderWidth  = 1
        btnLogin.layer.borderColor  = UIColor.white.cgColor
        btnLogin.addTarget(self, action: #selector(FilmDetailViewController.buyTicketsAction), for: UIControlEvents.touchUpInside)
        
        
        self.backBlackView.addSubview(cellText)
        self.backBlackView.addSubview(cellstyle)
        self.backBlackView.addSubview(celldes)
        self.backBlackView.addSubview(cellprice)
        self.backBlackView.addSubview(celltype)
        self.backBlackView.addSubview(btnLogin)
        self.backBlackView.addSubview(celltime)
        
        let cellDetail:UILabel = UILabel(frame:CGRect(x: 10, y: backBlackView.frame.size.height+backBlackView.frame.origin.y+10, width: self.view.frame.size.width-20 , height: 90))
        cellDetail.textColor = UIColor.darkGray
        cellDetail.font = UIFont(name:"ArialMT", size:13)
        cellDetail.text = "\(filmItem.gutdescipty)"
        cellDetail.numberOfLines = 0
        self.backWriteView.addSubview(cellDetail)
        HP_mostColor.setlbVerticalSpacing(cellDetail.text, lb: cellDetail)
        
        
        let cellPicture:UILabel = UILabel(frame:CGRect(x: 10, y: 10,width: 100 , height: 20))
        cellPicture.textColor = UIColor.darkText
        cellPicture.font = UIFont(name:"ArialMT", size:16)
        cellPicture.text = "剧照"
        self.backWite1View.addSubview(cellPicture)
        
        let scv : UIScrollView = UIScrollView(frame:CGRect(x: 0, y: 30, width: self.view.frame.size.width , height: 80))
        self.backWite1View.addSubview(scv)
        
        
        let ar : NSArray!
        ar = self.infoItem.picList as! NSArray;
        scv.contentSize = CGSize(width: 10+CGFloat(ar.count)*90+10, height: 0)
        for index:Int in 0 ..< ar.count {
            let items = FilmListItem.mj_object(withKeyValues: ar.object(at: index))
            let pik:UIImageView = UIImageView(frame:CGRect(x: 10+CGFloat(index)*90, y: 10, width: 80, height: 60))
            pik.sd_setImage(with: URL(string:"http://img.vcfilm.cn:8080/resource/\(items!.picture)"), placeholderImage : UIImage(named:"eom"))
            scv.addSubview(pik)
        }
        let cellMain:UILabel = UILabel(frame:CGRect(x: 10, y: 10,width: 100 , height: 20))
        cellMain.textColor = UIColor.darkText
        cellMain.font = UIFont(name:"ArialMT", size:16)
        cellMain.text = "主创"
        self.backWite2View.addSubview(cellMain)
        let cellDire:UILabel = UILabel(frame:CGRect(x: 10, y: 35,width: self.view.frame.size.width-20 , height: 20))
        cellDire.textColor = UIColor.darkText
        cellDire.font = UIFont(name:"ArialMT", size:13)
        cellDire.text = "导演:\(filmItem.directorName)"
        self.backWite2View.addSubview(cellDire)
        let cellActor:UILabel = UILabel(frame:CGRect(x: 10, y: 50,width: self.view.frame.size.width-20 , height: 40))
        cellActor.textColor = UIColor.darkText
        cellActor.font = UIFont(name:"ArialMT", size:13)
        cellActor.numberOfLines = 0
        cellActor.text = "主演:\(filmItem.actorName)"
        self.backWite2View.addSubview(cellActor)
        
        self.backWite2View .frame = CGRect(x:0,y:460,width: self.view.frame.size.width,height:cellActor.frame.size.height+cellActor.frame.origin.y+20)
        self.backgroudView = UIView(frame:CGRect(x:0,y:0, width: self.view.frame.size.width, height:self.backWite2View.frame.size.height+self.backWite2View.frame.origin.y+20));

        
        self.customtableView.reloadData()
    }
    func buyTicketsAction() -> Void {
        let tow_vc = JumpViewController();
        self.navigationController?.pushViewController(tow_vc, animated: false)
    }
    //根据影片ID请求热映影片评论
    func requestFilmReview(_ filmId:NSString) -> Void {
        let managers = AFHTTPSessionManager()
        let urls = "http://app.vcfilm.cn/review/queryReviewAndTag"
        let paramss = ["token":"a3e78fbef9103c6272ebd28c3fe70709","filmID":filmId,"platform":"5"]
        
        managers.post(urls, parameters: paramss, progress: nil, success: { (_, JSON) in
            print(JSON)
            guard  ((JSON as? [String : NSObject]) != nil) else{
                print("数据返回为空!")
                return
            }
            
            },failure: { (_, error) in
                print(error)
        })
        
    }
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        // 记录tabView的偏移量
        let offset:CGFloat  = scrollView.contentOffset.y
        if (offset <= 0) {
        }
        else{

        }
        if (offset<10) {
            self.headerView.backgroundColor = UIColor(red: 85.0/255, green: 51.0/255, blue: 201.0/255, alpha:0.0)
        }else {
            let alpha:CGFloat = 1-((200-offset)/200)
            self.headerView.backgroundColor = UIColor(red: 85.0/255, green: 51.0/255, blue: 201.0/255, alpha:alpha)
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{

            return 120
    
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        
//        let film:FilmListItem  = self.dataArray.objectAtIndex(indexPath.row) as! FilmListItem
        let cell: UITableViewCell = UITableViewCell(style: UITableViewCellStyle.subtitle, reuseIdentifier: "MyTestCell")
        
        cell.textLabel?.text = "ddkfvksdfvdfvdcmvdcms;dcdcm"
//        let cellImage:UIImageView = UIImageView(frame:CGRectMake(10, 10, 60, 90))
//        cellImage.sd_setImageWithURL(NSURL(string:"http://img.vcfilm.cn:8080/resource/\(film.picture)"), placeholderImage: UIImage(named:"eom"))
//        
//        let cellText:UILabel = UILabel(frame:CGRectMake(75, 10, 150, 20))
//        cellText.font = UIFont(name:"ArialMT", size:14)
//        cellText.text = "\(film.chname) "
//        cellText.sizeToFit()
//        
//        let cellstyle:UILabel = UILabel(frame:CGRectMake(cellText.frame.origin.x+cellText.frame.size.width, 10, 60, 20))
//        cellstyle.font = UIFont(name:"ArialMT", size:14)
//        cellstyle.backgroundColor = UIColor.blueColor()
//        cellstyle.layer.cornerRadius = 5
//        cellstyle.layer.masksToBounds = true
//        cellstyle.textColor = UIColor.whiteColor()
//        cellstyle.font = UIFont(name:"ArialMT", size:13)
//        cellstyle.text = "数字3D"
//        cellstyle.sizeToFit()
//        
//        let celldes:UILabel = UILabel(frame:CGRectMake(75, 30, 200, 20))
//        celldes.textColor = UIColor.lightGrayColor()
//        celldes.font = UIFont(name:"ArialMT", size:12)
//        celldes.text = "\(film.onlyDescribe) "
//        
//        let cellprice:UILabel = UILabel(frame:CGRectMake(75, 60, 200, 20))
//        cellprice.textColor = UIColor.redColor()
//        cellprice.font = UIFont(name:"ArialMT", size:13)
//        cellprice.text = "\(film.lprice)元起 "
//        
//        let celltype:UILabel = UILabel(frame:CGRectMake(75, 80, 200, 20))
//        celltype.textColor = UIColor.redColor()
//        celltype.font = UIFont(name:"ArialMT", size:13)
//        celltype.text = "\(film.pixtype) "
//        
//        let btnLogin:UIButton = UIButton(frame: CGRectMake(self.view.frame.size.width-70,70, 60, 30))
//        btnLogin.setTitle("购票", forState: UIControlState.Normal)
//        btnLogin.setTitleColor(UIColor.redColor(), forState: .Normal)
//        btnLogin.layer.cornerRadius = 5
//        btnLogin.layer.borderWidth  = 2
//        btnLogin.layer.borderColor  = UIColor.redColor().CGColor
//        btnLogin.addTarget(self, action: #selector(SFViewController.btnClick(_:)), forControlEvents: UIControlEvents.TouchUpInside)
//        
//        
//        cell.contentView.addSubview(cellImage)
//        cell.contentView.addSubview(cellText)
//        cell.contentView.addSubview(cellstyle)
//        cell.contentView.addSubview(celldes)
//        cell.contentView.addSubview(cellprice)
//        cell.contentView.addSubview(celltype)
//        cell.contentView.addSubview(btnLogin)
        return cell
    }

    func btnClick() -> Void {
        
        self.navigationController?.popViewController(animated: true)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
