//
//  FilmListItem.swift
//  MSF
//
//  Created by hipiao on 16/9/12.
//  Copyright © 2016年 caohan. All rights reserved.
//

import UIKit

class FilmListItem: NSObject {

    var data   : AnyObject = "" as AnyObject
    var meg    : AnyObject = "" as AnyObject
    var count  : Int       = 0
    var status : AnyObject = "" as AnyObject
    
    
    var chname       : NSString = ""
    var actorName    : NSString = ""
    var cinemaCount  : Int      = 0
    var country      : NSString = ""
    var directorName : NSString = ""
    var filmColor    : NSString = ""
    var filmID       : Int      = 0
    var filmTypeId   : Int      = 0
    var fshowtime    : NSString = ""
    var gutdescipty  : NSString = ""
    var picture      : NSString = ""
    var onlyDescribe : NSString = ""
    var pixlength    : Int      = 0
    var pixtype      : NSString = ""
    var typeName     : Int      = 0
    var lprice       : Int      = 0

}
