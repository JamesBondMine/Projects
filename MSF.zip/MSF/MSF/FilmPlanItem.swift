//
//  FilmPlanItem.swift
//  MSF
//
//  Created by hipiao on 16/9/26.
//  Copyright © 2016年 caohan. All rights reserved.
//

import UIKit

class FilmPlanItem: NSObject {
    
    
    var cinemaMrId : Int = 0
    var data       : AnyObject = "" as AnyObject
    var cityPrice  : Int = 0
    var list       : AnyObject = "" as AnyObject
    var likeRate   : AnyObject = "" as AnyObject
    var meg        : AnyObject = "" as AnyObject
    var status     : AnyObject = "" as AnyObject
    
    
    var cinemaId       : Int = 0
    var cstate         : Int = 0
    var endtime        : NSString = ""
    var filmCode       : Int = 0
    var filmId         : Int = 0
    var filmLanguage   : NSString = ""
    var fullPlayTime   : NSString = ""
    var hallCode       : Int = 0
    var hallId         : Int = 0
    var hallName       : NSString = ""
    var hasPromotion   : Int = 0
    var isSale         : Int = 0
    var lPrice         : Int = 0
    var planCode       : NSString = ""
    var planId         : Int = 0
    var playTimeLimit  : Int = 0
    var playTimeShow   : Int = 0
    var playtime       : NSString = ""
    var price          : Int = 0
    var promotionPrice : Int = 0
    var sprice         : Int = 0
    var typeName       : NSString = ""
    var vcSPrice       : Int = 0
    

}
