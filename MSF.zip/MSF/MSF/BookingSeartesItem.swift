//
//  BookingSeartesItem.swift
//  MSF
//
//  Created by hipiao on 16/9/27.
//  Copyright © 2016年 caohan. All rights reserved.
//

import UIKit

class BookingSeartesItem: NSObject {

    var data           : AnyObject = "" as AnyObject
    var groupType      : Int       = 0
    var status         : Int       = 0
    
    
    var cinemaGroupId  : NSString = ""
    var cinemaSeatId   : NSString = ""
    var createTime     : NSString = ""
    var creatorId      : NSString = ""
    var floor          : NSString = ""
    var handlerId      : NSString = ""
    var recordDealTime : NSString = ""
    var seatType       : NSString = ""
    var bestSeat       : Int      = 0
    var colnum         : Int      = 0
    var delFlag        : Int      = 0
    var hallId         : Int      = 0
    var id             : Int      = 0
    var linenum        : Int      = 0
    var state          : Int      = 0
    var xpoint         : Int      = 0
    var ypoint         : Int      = 0
    
    
    //已经售出座位
    var seatID         : NSString = ""
    var layerNo        : NSString = ""
    var groupCode      : NSString = ""
    var code           : NSString = ""
    var cinemaSeatID   : NSString = ""
    var yCoord         : Int      = 0
    var xCoord         : Int      = 0
    var rowNum         : Int      = 0
    var columnNum      : Int      = 0
    
    
}
