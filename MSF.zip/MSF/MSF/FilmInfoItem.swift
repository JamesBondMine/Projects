//
//  FilmInfoItem.swift
//  MSF
//
//  Created by hipiao on 16/9/14.
//  Copyright © 2016年 caohan. All rights reserved.
//

import UIKit

class FilmInfoItem: NSObject {

    
    var filmInfo : AnyObject = "" as AnyObject
    var picList  : AnyObject = "" as AnyObject
    
    var filmName     : NSString = ""
    var actorName    : NSString = ""
    var cinemaCount  : Int      = 0
    var country      : NSString = ""
    var directorName : NSString = ""
    var detailPicture: NSString = ""
    var filmID       : Int      = 0
    var filmTypeId   : Int      = 0
    var fshowtime    : NSString = ""
    var gutdescipty  : NSString = ""
    var picture      : NSString = ""
    var onlyDescribe : NSString = ""
    var pixlength    : Int      = 0
    var pixtype      : NSString = ""
    var typeName     : Int      = 0
    var lprice       : Int      = 0
    var score        : Int      = 0
    
    
}
