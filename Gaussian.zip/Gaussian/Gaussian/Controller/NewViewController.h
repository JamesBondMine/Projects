//
//  NewViewController.h
//  Gaussian
//
//  Created by hipiao on 16/11/2.
//  Copyright © 2016年 James. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewViewController : UIViewController



@end
