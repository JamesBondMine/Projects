//
//  NewViewController.m
//  Gaussian
//
//  Created by hipiao on 16/11/2.
//  Copyright © 2016年 James. All rights reserved.
//

#import "NewViewController.h"

@interface NewViewController ()

@end

@implementation NewViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createUi];
}
-(void)createUi{

    self.view.backgroundColor = [UIColor whiteColor];
    UIButton * btnBack = [UIButton buttonWithType:UIButtonTypeCustom];
    [btnBack setFrame:CGRectMake(0, 80, 120, 40)];
    btnBack.backgroundColor = [UIColor redColor];
    [self.view addSubview:btnBack];
    [btnBack addTarget:self action:@selector(baclViewAction) forControlEvents:UIControlEventTouchUpInside];

}
-(void)baclViewAction{
    [self dismissViewControllerAnimated:YES completion:nil];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
