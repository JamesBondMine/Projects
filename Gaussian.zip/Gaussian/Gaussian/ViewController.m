//
//  ViewController.m
//  Gaussian
//
//  Created by hipiao on 16/9/8.
//  Copyright © 2016年 James. All rights reserved.
//

#import "ViewController.h"
#import "NewViewController.h"
#import "UIImage+ImageEffects.h"

@interface ViewController ()
{

    CGFloat rectView;
    CGPoint     location;
}
@property (nonatomic,strong) UIView * signedView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createUi];
    [self createSignedView];
}
-(void)createUi{
    UIScrollView * sc = [[UIScrollView alloc]initWithFrame:self.view.bounds];
    [self.view addSubview:sc];
    
    UIImageView * image = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width/2, 200)];
     [image sd_setImageWithURL:[NSURL URLWithString:@"http://b30.photo.store.qq.com/psu?/b92481b7-a9e7-4aad-9040-8e00215ef968/Q.VoF6Zxgg1QbP*6mpXJ6lSa.mWSBrHikykhgyqXI4s!/m/YfPb7RF*cAAAYvwP.hEzcAAA&bo=iwByAAAAAAABAN4!&rf=photolist"] placeholderImage:[UIImage imageNamed:@"beaytyfilter_120"]];
    image.backgroundColor = [UIColor redColor];
    [sc addSubview:image];
    
    UIImageView * image1 = [[UIImageView alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2, 0, self.view.frame.size.width/2, 200)];
    [image1 setImage:[[UIImage imageNamed:@"beaytyfilter_120.png"] applyDarkEffect]];
    [sc addSubview:image1];
    
    UIImageView * image11 = [[UIImageView alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2, 0, self.view.frame.size.width/2, 200)];
    [image11 setImage:[[UIImage imageNamed:@"beaytyfilter_120.png"] applyLightEffect]];
    [sc addSubview:image11];
    
    UIImageView * image111 = [[UIImageView alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2, 200, self.view.frame.size.width/2, 200)];
    [image111 setImage:[[UIImage imageNamed:@"beaytyfilter_120.png"] applyExtraLightEffect]];
    [sc addSubview:image111];
    
    UIImageView * image1111 = [[UIImageView alloc]initWithFrame:CGRectMake(0, 200, self.view.frame.size.width/2, 200)];
    [image1111 setImage:[[UIImage imageNamed:@"beaytyfilter_120.png"] applyTintEffectWithColor:[UIColor redColor]]];
    [sc addSubview:image1111];
    
    UIImageView * image11111 = [[UIImageView alloc]initWithFrame:CGRectMake(0, 400, self.view.frame.size.width/2, 200)];
    [image11111 setImage:[[UIImage imageNamed:@"beaytyfilter_120.png"] applyBlurWithRadius:8 tintColor:[UIColor colorWithWhite:1 alpha:0.1] saturationDeltaFactor:2.0 maskImage:nil]];
    [sc addSubview:image11111];
    
    sc.contentSize = CGSizeMake(0, image11111.frame.origin.y+image11111.frame.size.height);
    
    
    
}
-(void)createSignedView{
    rectView = ScreenWidth*70/320;
    self.signedView = [[UIView alloc]initWithFrame:CGRectMake(ScreenWidth-150, ScreenHeight-200, rectView, rectView)];
    self.signedView.backgroundColor = [UIColor redColor];
    self.signedView.layer.masksToBounds = YES;
    self.signedView.layer.cornerRadius  = rectView/2;
    [self.view addSubview:self.signedView];
    //添加单击手势
    UITapGestureRecognizer * tapSize = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapSize:)];
    tapSize.numberOfTapsRequired     = 1;
    tapSize.numberOfTouchesRequired  = 1;
    [self.signedView addGestureRecognizer:tapSize];
    //添加拖拽手势
    UIPanGestureRecognizer * panGesture=[[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(handGesture:)];
    panGesture.minimumNumberOfTouches = 1;
    panGesture.maximumNumberOfTouches = 1;
    [self.signedView addGestureRecognizer:panGesture];
    
}
-(void)handGesture:(UIPanGestureRecognizer *)paramSender{
    
    location = [paramSender locationInView:paramSender.view.superview];
    paramSender.view.center = CGPointMake(location.x,location.y);
    if (location.x<=rectView/2) {//处理左边框
        [UIView animateWithDuration:0.25 animations:^{
            paramSender.view.center = CGPointMake(location.x+(40-location.x),location.y);
        }];
    }
    if (location.x>= ScreenWidth-rectView/2) {//处理右边框
        [UIView animateWithDuration:0.25 animations:^{
            paramSender.view.center = CGPointMake(location.x-(location.x-(ScreenWidth-rectView/2)),location.y);
        }];
    }
    if (location.y<=rectView/2) {
        [UIView animateWithDuration:0.25 animations:^{//处理顶部
            paramSender.view.center = CGPointMake(location.x,location.y+(rectView/2-location.y));
        }];
    }
    if (location.y>=ScreenHeight-rectView/2-64-48) {
        [UIView animateWithDuration:0.25 animations:^{//处理底部
            paramSender.view.center = CGPointMake(location.x,location.y-(location.y-(ScreenHeight-64-48-rectView/2)));
        }];
    }
    if (location.x<=rectView/2&&location.y<=rectView/2) {//处理左上角
        [UIView animateWithDuration:0.25 animations:^{
            paramSender.view.center = CGPointMake(location.x+(rectView/2-location.x),location.y+(rectView/2-location.y));
        }];
    }
    if (location.x>= ScreenWidth-rectView/2&&location.y<=rectView/2) {//处理右上角
        [UIView animateWithDuration:0.25 animations:^{
            paramSender.view.center = CGPointMake(location.x-(location.x-(ScreenWidth-rectView/2)),location.y+(rectView/2-location.y));
        }];
    }
    if (location.x<=rectView/2&&location.y>=ScreenHeight-rectView/2-64-48) {//处理左下角
        [UIView animateWithDuration:0.25 animations:^{
            paramSender.view.center = CGPointMake(location.x+(rectView/2-location.x),location.y-(location.y-(ScreenHeight-64-48-rectView/2)));
        }];
    }
    if (location.x>= ScreenWidth-rectView/2&&location.y>=ScreenHeight-rectView/2-64-48) {//处理又下角
        [UIView animateWithDuration:0.25 animations:^{
            paramSender.view.center = CGPointMake(location.x-(location.x-(ScreenWidth-rectView/2)),location.y-(location.y-(ScreenHeight-64-48-rectView/2)));
        }];
    }
}
-(void)tapSize:(UITapGestureRecognizer *)tap{

    NewViewController * new = [[NewViewController alloc]init];
    [self presentViewController:new animated:YES completion:nil];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
